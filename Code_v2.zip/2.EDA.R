rm(list = ls())  # 모든 객체 삭제
gc()  # 메모리 정리
setwd("C:/Project/Data/")

# 교재 66 페이지
##################################
# 1. 종사자수, 사업체수
##################################
# 1. Business_Survey_Base.Rdata 파일을 불러와서 데이터프레임 생성
load("C:/Project/Data/Business_Survey_Base.Rdata")

# 2. 전체 사업체 수, 종사자 수, 평균 종사자 수 계산
# 각 레코드는 하나의 사업체를 의미하므로, 사업체 수는 행의 개수
total_businesses <- nrow(Business_Survey)

# 종사자수_계_합계라는 컬럼명을 사용하여 종사자 수 합계 계산
total_employees <- sum(Business_Survey$종사자수_계_합계, na.rm = TRUE)

# 평균 종사자 수 계산
average_employees <- total_employees / total_businesses

# 결과 출력
cat("전체 사업체 수:", total_businesses, "\n")
cat("전체 종사자 수:", total_employees, "\n")
cat("평균 종사자 수:", round(average_employees, 2), "\n")


library(dplyr)
library(ggplot2)

# install.packages("showtext")
library(showtext)

# 폰트 등록
font_add(family = "SeoulNamsan", regular = "C:/Windows/Fonts/SeoulNamsanL.ttf")

# showtext 활성화 (그래프에 적용되도록)
showtext_auto()


# 구별 요약
district_summary <- Business_Survey %>%
  group_by(구) %>%
  summarise(
    사업체수 = n(),  # 각 구의 레코드 수 = 사업체 수
    종사자수 = sum(종사자수_계_합계, na.rm = TRUE)
  ) %>%
  arrange(desc(종사자수))  # 종사자수 기준 내림차순

# 요약 데이터프레임 출력
print(district_summary)

# 교재 68 페이지
##################################
# 2. 종사자 규모별 사업체수
##################################

library(dplyr)
library(ggplot2)
library(scales)

# 종사자 수 기준으로 사업체 규모 분류 및 요약
firm_by_size <- Business_Survey %>%
  filter(!is.na(종사자수_계_합계)) %>%
  mutate(
    규모 = case_when(
      종사자수_계_합계 >= 1   & 종사자수_계_합계 <= 4   ~ "1~4인",
      종사자수_계_합계 >= 5   & 종사자수_계_합계 <= 9   ~ "5~9인",
      종사자수_계_합계 >= 10  & 종사자수_계_합계 <= 49  ~ "10~49인",
      종사자수_계_합계 >= 50  & 종사자수_계_합계 <= 99  ~ "50~99인",
      종사자수_계_합계 >= 100 & 종사자수_계_합계 <= 299 ~ "100~299인",
      종사자수_계_합계 >= 300                             ~ "300인 이상",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(규모)) %>%
  group_by(규모) %>%
  summarise(
    사업체수 = n(),
    .groups = "drop"
  ) %>%
  mutate(
    비율 = 사업체수 / sum(사업체수),
    규모 = factor(규모, levels = c("1~4인", "5~9인", "10~49인", "50~99인", "100~299인", "300인 이상"))
  )

windows(width = 18, height = 10)
ggplot(firm_by_size, aes(x = 규모)) +
  geom_col(aes(y = 사업체수), fill = "steelblue") +
  
  geom_text(
    aes(y = 사업체수 + max(사업체수) * 0.02, label = percent(비율, accuracy = 1)),
    color = "black",
    size = 4,
    family = "SeoulNamsan"
  ) +
  
  geom_line(aes(y = 비율 * max(사업체수), group = 1), color = "darkred", size = 1.2) +
  geom_point(aes(y = 비율 * max(사업체수)), color = "darkred", size = 2) +
  
  scale_y_continuous(
    name = "사업체 수",
    labels = comma,
    sec.axis = sec_axis(~ . / max(firm_by_size$사업체수), name = "비율", labels = percent_format(accuracy = 1))
  ) +
  
  labs(
    title = "종사자 규모별 사업체 수 및 비율",
    x = "종사자 규모"
  ) +
  
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.title.x = element_text(size = 16),
    axis.title.y.left = element_text(size = 16, color = "steelblue"),
    axis.title.y.right = element_text(size = 16, color = "darkred"),
    axis.text.x = element_text(size = 14)  # ✅ 여기! X축 눈금 글자 크기 키움
  )

# 항목	추천 값 (px)	설명
# axis.title.x	14–18	하단 X축 제목 (ex: “종사자 규모”)
# axis.title.y.*	14–18	Y축 제목 (좌/우 모두 적용 가능)
# plot.title	18–24	그래프 제목

# 교재 71 페이지
##################################
# 3. 산업별 사업체수
##################################
library(dplyr)
library(ggplot2)
library(scales)

# 1. 산업별 사업체 수 및 비율 계산 (내림차순 정렬)
industry_summary <- Business_Survey %>%
  filter(!is.na(주사업_산업분류부호_대분류항목명)) %>%
  group_by(산업 = 주사업_산업분류부호_대분류항목명) %>%
  summarise(
    사업체수 = n(),
    .groups = "drop"
  ) %>%
  mutate(
    비율 = 사업체수 / sum(사업체수),
    산업 = reorder(산업, -사업체수)  # 내림차순 정렬
  )

windows(width = 18, height = 10)
ggplot(industry_summary, aes(x = 산업)) +
  geom_col(aes(y = 사업체수), fill = "steelblue") +
  geom_line(aes(y = 비율 * max(사업체수), group = 1), color = "darkred", size = 1.2) +
  geom_point(aes(y = 비율 * max(사업체수)), color = "darkred", size = 2) +
  scale_y_continuous(
    name = "사업체 수",
    labels = comma,
    sec.axis = sec_axis(~ . / max(industry_summary$사업체수), name = "비율", labels = percent_format(accuracy = 1))
  ) +
  labs(
    title = "산업 대분류별 사업체 수 및 전체 대비 비율",
    x = "산업 대분류",
    y = "사업체 수"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    axis.text.x = element_text(size = 12, angle = 45, hjust = 1),  # ← 여기서 글자 크기 조절
    axis.title.y.left = element_text(color = "steelblue"),
    axis.title.y.right = element_text(color = "darkred"),
    plot.title = element_text(size = 24, face = "bold", hjust = 0.5) # ← 폰트 사이즈 조정
  )

# size = 12 → 원하는 크기로 조절 (예: 14, 16 등)
# angle = 45 → 기울기 조절 가능 (예: 30도, 60도 등)
# hjust = 1 → 오른쪽 정렬 (hjust = 0.5는 가운데 정렬)

# 교재 71 페이지
##################################
# 4. 산업별 종사자수
##################################
library(dplyr)
library(ggplot2)
library(scales)

# 1. 데이터 집계
industry_emp_summary <- Business_Survey %>%
  filter(!is.na(주사업_산업분류부호_대분류항목명)) %>%
  group_by(주사업_산업분류부호_대분류항목명) %>%
  summarise(종사자수 = sum(종사자수_계_합계, na.rm = TRUE)) %>%
  mutate(
    비율 = 종사자수 / sum(종사자수) * 100
  )

# 2. 최대값 저장
max_emp <- max(industry_emp_summary$종사자수)

windows(width = 18, height = 10)
# 3. 이중축 그래프 생성 (좌측부터 내림차순 정렬)
ggplot(industry_emp_summary, aes(x = reorder(주사업_산업분류부호_대분류항목명, -종사자수))) +
  geom_col(aes(y = 종사자수), fill = "steelblue", width = 0.6) +
  geom_line(aes(y = 비율 * max_emp / 100, group = 1), color = "firebrick", size = 1.2) +
  geom_point(aes(y = 비율 * max_emp / 100), color = "firebrick", size = 2) +
  scale_y_continuous(
    name = "종사자 수",
    labels = comma,
    sec.axis = sec_axis(~ . * 100 / max_emp, name = "전체 종사자 중 비율 (%)", labels = percent_format(scale = 1))
  ) +
  labs(
    title = "산업별 종사자 수 및 비율",
    x = "산업 대분류 항목명"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5)
  )

# 교재 77 페이지
##################################
# 5. 조직형태별 사업체수
##################################

library(dplyr)
library(ggplot2)
library(scales)

# 1. 조직형태 코드 라벨링
Business_Survey <- Business_Survey %>%
  mutate(
    조직형태_라벨 = case_when(
      조직형태 == "1" ~ "개인사업체",
      조직형태 == "2" ~ "회사법인",
      조직형태 == "3" ~ "회사이외법인",
      조직형태 == "4" ~ "비법인단체",
      조직형태 == "5" ~ "국가·지자체",
      TRUE ~ "기타 또는 미상"
    )
  )


org_summary <- Business_Survey %>%
  filter(!is.na(조직형태_라벨)) %>%
  group_by(조직형태_라벨) %>%
  summarise(
    사업체수 = n(),
    .groups = "drop"
  ) %>%
  mutate(
    비율 = 사업체수 / sum(사업체수),
    조직형태_라벨 = factor(조직형태_라벨,
                     levels = c("개인사업체", "회사법인", "회사이외법인", "비법인단체", "국가·지자체", "기타 또는 미상"))
  )

windows(width = 18, height = 10)
ggplot(org_summary, aes(x = 조직형태_라벨)) +
  # 막대: 사업체 수
  geom_col(aes(y = 사업체수), fill = "steelblue") +
  
  # 비율 선그래프
  geom_line(aes(y = 비율 * max(사업체수), group = 1), color = "darkred", size = 1.2) +
  geom_point(aes(y = 비율 * max(사업체수)), color = "darkred", size = 2) +
  
  # 비율 텍스트 레이블 (막대 위)
  geom_text(
    aes(y = 사업체수 + max(사업체수)*0.03, label = percent(비율, accuracy = 1)),
    size = 4,
    family = "SeoulNamsan",
    color = "black"
  ) +
  
  # Y축 설정
  scale_y_continuous(
    name = "사업체 수",
    labels = comma,
    sec.axis = sec_axis(~ . / max(org_summary$사업체수), name = "비율", labels = percent_format(accuracy = 1))
  ) +
  
  labs(
    title = "조직형태별 사업체 수 및 전체 대비 비율",
    x = "조직형태"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.title.x = element_text(size = 16),
    axis.title.y.left = element_text(size = 16, color = "steelblue"),
    axis.title.y.right = element_text(size = 16, color = "darkred"),
    axis.text.x = element_text(size = 14)
  )

# 교재 80 페이지
##################################
# 6. 대표자 성별/연령별 사업체수
##################################

library(dplyr)
library(ggplot2)
library(scales)

# 전처리: 성별 및 연령대 라벨 정리
Business_Survey <- Business_Survey %>%
  mutate(
    성별 = case_when(
      대표자성별 == "1" ~ "남",
      대표자성별 == "2" ~ "여",
      TRUE ~ "미상"
    ),
    연령대 = case_when(
      대표자연령대 %in% c("1", "2") ~ "29세 이하",
      대표자연령대 == "3" ~ "30세~39세",
      대표자연령대 == "4" ~ "40세~49세",
      대표자연령대 == "5" ~ "50세~59세",
      대표자연령대 %in% c("6", "7", "8", "9") ~ "60세 이상",
      TRUE ~ "미상"
    ),
    연령대 = factor(연령대, levels = c("29세 이하", "30세~39세", "40세~49세", "50세~59세", "60세 이상"))
  )

# 집계
age_gender_summary <- Business_Survey %>%
  filter(성별 %in% c("남", "여"), !is.na(연령대)) %>%
  count(연령대, 성별, name = "사업체수")

# 그래프
windows(width = 18, height = 10)
ggplot(age_gender_summary, aes(x = 연령대, y = 사업체수, fill = 성별)) +
  geom_col(position = "dodge", width = 0.6) +
  geom_text(
    aes(label = comma(사업체수)),
    position = position_dodge(width = 0.6),
    vjust = -0.3,
    size = 4,
    family = "SeoulNamsan"
  ) +
  scale_fill_manual(values = c("남" = "skyblue", "여" = "pink")) +
  scale_y_continuous(labels = comma) +
  labs(
    title = "대표자 성별·연령대별 사업체 수",
    x = "연령대",
    y = "사업체 수",
    fill = "성별"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 12)
  )

# 교재 83 페이지
#####################################
# 6-1. 산업별 대표자 연령별 사업체수
#####################################

library(dplyr)
library(tidyr)

# 1. 연령대 라벨 변환
Business_Survey <- Business_Survey %>%
  mutate(
    연령대 = case_when(
      대표자연령대 == "1" ~ "20대 미만",
      대표자연령대 == "2" ~ "20대",
      대표자연령대 == "3" ~ "30대",
      대표자연령대 == "4" ~ "40대",
      대표자연령대 == "5" ~ "50대",
      대표자연령대 == "6" ~ "60대",
      대표자연령대 == "7" ~ "70대",
      대표자연령대 == "8" ~ "80대",
      대표자연령대 == "9" ~ "90대 이상",
      TRUE ~ NA_character_
    ),
    연령대 = factor(연령대, levels = c("20대 미만", "20대", "30대", "40대", "50대", "60대", "70대", "80대", "90대 이상"))
  )

# 2. 산업 대분류코드별, 연령대별 사업체 수 요약
industry_age_summary <- Business_Survey %>%
  filter(!is.na(주사업_산업분류부호_대분류코드), !is.na(연령대)) %>%
  group_by(산업코드 = 주사업_산업분류부호_대분류항목명, 연령대) %>%
  summarise(사업체수 = n(), .groups = "drop") %>%
  pivot_wider(
    names_from = 연령대,
    values_from = 사업체수,
    values_fill = 0
  ) %>%
  arrange(산업코드)

# 설치

# install.packages("writexl")

# 패키지 로드
library(writexl)

# 작업 디렉터리 설정
setwd("C:/Project/Data/")

# 엑셀 파일 저장 (파일명은 원하는 대로 변경 가능)
write_xlsx(industry_age_summary, path = "산업별대표자연령대별집계정보.xlsx")

# 교재 85 페이지
####################################
# 7. 자치구별 종사자수 막대 그래프
####################################
# install.packages("ggplot2")
# install.packages("scales")

library(ggplot2)
library(scales)
library(showtext)

str(district_summary)

# ✅ 레이블용 숫자 (천 단위 콤마 처리)
district_summary <- district_summary %>%
  mutate(label_text = comma(종사자수))

# ✅ 시각화
windows(width = 18, height = 10)
ggplot(district_summary, aes(x = reorder(구, -종사자수), y = 종사자수)) +
  geom_bar(stat = "identity", fill = "dodgerblue") +
  geom_text(aes(label = label_text), vjust = -0.3, size = 4, family = "SeoulNamsan") +
  labs(
    title = "서울시 자치구별 종사자 수",
    x = "자치구",
    y = "종사자 수"
  ) +
  scale_y_continuous(
    labels = comma,
    expand = expansion(mult = c(0, 0.05))  # 위쪽 여백 확보
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    axis.text.x = element_text(size = 16, angle = 45, hjust = 1),
    axis.text.y = element_text(size = 16)
  )


####################################
# 7-2 자치구별 사업체수 막대 그래프
####################################

# ✅ 레이블용 숫자 (천 단위 콤마 처리)
district_summary <- district_summary %>%
  mutate(label_text = comma(사업체수))

# ✅ 시각화
windows(width = 18, height = 10)
ggplot(district_summary, aes(x = reorder(구, -사업체수), y = 사업체수)) +
  geom_bar(stat = "identity", fill = "dodgerblue") +
  geom_text(aes(label = label_text), vjust = -0.3, size = 4, family = "SeoulNamsan") +
  labs(
    title = "서울시 자치구별 사업체수",
    x = "자치구",
    y = "사업체수"
  ) +
  scale_y_continuous(
    labels = comma,
    expand = expansion(mult = c(0, 0.05))  # 위쪽 여백 확보
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    axis.text.x = element_text(size = 16, angle = 45, hjust = 1),
    axis.text.y = element_text(size = 16)
  )

# 교재 86 페이지
#############################################
# 7-3 자치구별 사업체수/종사자수 막대 그래프
#############################################

library(ggplot2)
library(scales)
library(showtext)

# 종사자수를 사업체수 기준으로 스케일 맞춰 변환
max_business <- max(district_summary$사업체수)
max_employee <- max(district_summary$종사자수)
scaling_factor <- max_business / max_employee

district_summary$종사자수_스케일 <- district_summary$종사자수 * scaling_factor

windows(width = 18, height = 10)
ggplot(district_summary, aes(x = reorder(구, -사업체수))) +
  # 사업체수: 왼쪽 Y축 (막대그래프)
  geom_bar(aes(y = 사업체수), stat = "identity", fill = "steelblue") +
  
  # 종사자수: 오른쪽 Y축 (선그래프)
  geom_line(aes(y = 종사자수_스케일, group = 1), color = "tomato", size = 1.2) +
  geom_point(aes(y = 종사자수_스케일), color = "tomato", size = 2) +
  
  # 축 및 제목 설정
  scale_y_continuous(
    name = "사업체 수", 
    labels = comma,
    sec.axis = sec_axis(~ . / scaling_factor, name = "종사자 수", labels = comma)
  ) +
  labs(
    title = "서울시 자치구별 사업체수 및 종사자수",
    x = "자치구"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    axis.text.x  = element_text(size = 16, angle = 45, hjust = 1),
    axis.text.y  = element_text(size = 16),
    axis.text.y.right = element_text(size = 12, color = "tomato"),
    axis.title.y.right = element_text(color = "tomato", size = 12)
  )

# 교재 91 페이지
########################################
# 7-4 자치구별 사업체수 히트맵 그래프
########################################

# 데이터프레임 district_summary는 이미 존재한다고 가정
# 위치와 정규화 정보 추가
district_summary <- district_summary %>%
  arrange(desc(사업체수)) %>%
  mutate(
    row = rep(1:5, each = 5),
    col = rep(1:5, times = 5),
    정규화 = (사업체수 - min(사업체수)) / (max(사업체수) - min(사업체수))
  )

# ✔ 색상 팔레트 정의: 파랑 → 노랑 → 주홍
palette_fn <- colorRampPalette(c("#2980b9", "#f1c40f", "#e74c3c"))  # blue → yellow → red-orange

# 시각화
windows(width = 10, height = 10)
ggplot(district_summary, aes(x = col, y = -row)) +
  geom_tile(aes(fill = 정규화), color = "white") +
  geom_text(aes(label = 구), color = "white", family = "SeoulNamsan", size = 5, fontface = "bold") +
  scale_fill_gradientn(colors = palette_fn(100)) +
  theme_void(base_family = "SeoulNamsan") +
  ggtitle("자치구별 사업체수 히트맵") +
  theme(
    plot.title = element_text(hjust = 0.5, size = 30, face = "bold")
  )



########################################
# 7-5 자치구별 종사자수 히트맵 그래프
########################################

# 데이터프레임 district_summary는 이미 존재한다고 가정
# 위치와 정규화 정보 추가
district_summary <- district_summary %>%
  arrange(desc(종사자수)) %>%
  mutate(
    row = rep(1:5, each = 5),
    col = rep(1:5, times = 5),
    정규화 = (종사자수 - min(종사자수)) / (max(종사자수) - min(종사자수))
  )

# ✔ 색상 팔레트 정의: 파랑 → 노랑 → 주홍
palette_fn <- colorRampPalette(c("#2980b9", "#f1c40f", "#e74c3c"))  # blue → yellow → red-orange

# 시각화
windows(width = 10, height = 10)
ggplot(district_summary, aes(x = col, y = -row)) +
  geom_tile(aes(fill = 정규화), color = "white") +
  geom_text(aes(label = 구), color = "white", family = "SeoulNamsan", size = 5, fontface = "bold") +
  scale_fill_gradientn(colors = palette_fn(100)) +
  theme_void(base_family = "SeoulNamsan") +
  ggtitle("자치구별 종사자수 히트맵") +
  theme(
    plot.title = element_text(hjust = 0.5, size = 30, face = "bold")
  )

# 교재 95 페이지
#######################################
# 7-6 자치구별 사업체수 지도에 그리기
#######################################

# 필요한 패키지 설치 (한 번만 실행)
# install.packages(c("dplyr", "ggplot2", "sf", "readr", "ggthemes", "RColorBrewer"))

library(dplyr)
library(ggplot2)
library(sf)
library(scales)

# 자치구별 사업체 수 요약
gu_summary <- Business_Survey %>%
  group_by(구) %>%
  summarise(사업체수 = n()) %>%
  mutate(사업체비율 = 사업체수 / sum(사업체수) * 100)


# 서울시 자치구 GeoJSON 파일 (공공 저장소 예시)
# url <- "https://raw.githubusercontent.com/taeminlee/kostat-map/main/data/seoul/seoul_sig.json"
# temp_geo <- tempfile(fileext = ".json")
# download.file(url, temp_geo, mode = "wb")
# seoul_map <- st_read(temp_geo, quiet = TRUE)

# GeoJSON 파일 불러오기 (이미 불러온 경우 생략)
seoul_map <- st_read("C:/Project/Data/seoul_municipalities_geo_simple.json", quiet = TRUE) %>%
             rename(구 = name)

# 데이터 병합
map_data <- left_join(seoul_map, gu_summary, by = "구")

# 지도 중심 좌표 계산 (레이블용)
map_data_centroids <- map_data %>%
  st_centroid() %>%
  mutate(label = paste0(구, "\n", comma(사업체수)))  # 줄바꿈으로 표시

# 지도 그리기
windows(width = 15, height = 10)
ggplot(map_data) +
  geom_sf(aes(fill = 사업체수), color = "white", size = 0.3) +
  scale_fill_gradient(
    low = "lightyellow", high = "red",
    na.value = "grey90",
    labels = comma,
    name = "사업체 수"
  ) +
  geom_sf_text(
    data = map_data_centroids,
    aes(label = label),
    size = 3.5, family = "SeoulNamsan", fontface = "bold", color = "black"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  labs(
    title = "서울시 자치구별 사업체 수",
    caption = "자료: 2023년 전국사업체조사"
  ) +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    legend.title = element_text(size = 13),
    legend.text = element_text(size = 11)
  )

# 교재 98 페이지
#######################################
# 7-7 자치구별 종사자수 지도에 그리기
#######################################

# 필요한 패키지 설치 (한 번만 실행)
# install.packages(c("dplyr", "ggplot2", "sf", "readr", "ggthemes", "RColorBrewer"))

library(dplyr)
library(ggplot2)
library(sf)
library(scales)
library(showtext)

# 자치구별 종사자수 요약
gu_summary <- Business_Survey %>%
  group_by(구) %>%
  summarise(종사자수 = sum(종사자수_계_합계, na.rm = TRUE)) %>%
  mutate(종사자수비율 = 종사자수 / sum(종사자수) * 100)


# GeoJSON 파일 불러오기 (이미 불러온 경우 생략)
seoul_map <- st_read("C:/Project/Data/seoul_municipalities_geo_simple.json", quiet = TRUE) %>%
  rename(구 = name)

# 데이터 병합
map_data <- left_join(seoul_map, gu_summary, by = "구")

# 지도 중심 좌표 계산 (레이블용)
map_data_centroids <- map_data %>%
  st_centroid() %>%
  mutate(label = paste0(구, "\n", comma(종사자수)))  # 줄바꿈으로 표시

# 지도 그리기
windows(width = 15, height = 10)
ggplot(map_data) +
  geom_sf(aes(fill = 종사자수), color = "white", size = 0.3) +
  scale_fill_gradient(
    low = "lightyellow", high = "red",
    na.value = "grey90",
    labels = comma,
    name = "종사자 수"
  ) +
  geom_sf_text(
    data = map_data_centroids,
    aes(label = label),
    size = 3.5, family = "SeoulNamsan", fontface = "bold", color = "black"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  labs(
    title = "서울시 자치구별 종사자 수",
    caption = "자료: 2023년 전국사업체조사"
  ) +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    legend.title = element_text(size = 13),
    legend.text = element_text(size = 11)
  )

# 교재 100 페이지
########################################
# 8. 자치구별 성별/연령대별 그래프
########################################
# 8-1. 대표자 연령별, 성별 사업체수

library(dplyr)
library(ggplot2)

# 연령대와 성별 라벨 부여
Business_Survey <- Business_Survey %>%
  mutate(
    연령대 = case_when(
      대표자연령대 == "1" ~ "20대 미만",
      대표자연령대 == "2" ~ "20대",
      대표자연령대 == "3" ~ "30대",
      대표자연령대 == "4" ~ "40대",
      대표자연령대 == "5" ~ "50대",
      대표자연령대 == "6" ~ "60대",
      대표자연령대 == "7" ~ "70대",
      대표자연령대 == "8" ~ "80대",
      대표자연령대 == "9" ~ "90대 이상",
      TRUE ~ NA_character_
    ),
    성별 = case_when(
      대표자성별 == "1" ~ "남성",
      대표자성별 == "2" ~ "여성",
      TRUE ~ NA_character_
    ),
    연령대 = factor(연령대, levels = 
                   c("20대 미만", "20대", "30대", "40대", "50대", "60대", "70대", "80대", "90대 이상")),
    성별 = factor(성별, levels = c("남성", "여성"))
  )


age_gender_summary <- Business_Survey %>%
  filter(!is.na(연령대), !is.na(성별)) %>%
  count(연령대, 성별, name = "사업체수") %>%
  pivot_wider(
    names_from = 성별,
    values_from = 사업체수,
    values_fill = 0
  ) %>%
  mutate(
    총사업체수 = 남성 + 여성,
    남성비율 = 남성 / 총사업체수 * 100,
    여성비율 = 여성 / 총사업체수 * 100,
    성비율차이 = 남성비율 - 여성비율
  )


age_gender_summary <- Business_Survey %>%
  filter(!is.na(연령대), !is.na(성별)) %>%
  count(연령대, name = "사업체수") %>%
  mutate(비율 = 사업체수 / sum(사업체수) * 100)


age_gender_summary <- Business_Survey %>%
  filter(!is.na(연령대), !is.na(성별)) %>%
  count(연령대,성별, name = "사업체수") 

windows(width = 15, height = 10)
ggplot(age_gender_summary, aes(x = 연령대, y = 사업체수, fill = 성별)) +
  geom_col(position = "dodge") +
  labs(
    title = "대표자 연령대별·성별 사업체 수",
    x = "연령대",
    y = "사업체 수",
    fill = "성별"
  ) +
  scale_y_continuous(labels = scales::comma) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5)
  )

# 교재 102 페이지
# 8-2. 데이터 요약: 자치구별 성별·연령대별 사업체 수 집계
summary_data <- Business_Survey %>%
  group_by(구, 대표자성별, 대표자연령대) %>%
  summarise(사업체수 = n(), .groups = "drop") %>%
  mutate(
    성별 = case_when(
      대표자성별 == "1" ~ "남",
      대표자성별 == "2" ~ "여",
      TRUE ~ "기타"
    )
  )

# 8-3. 시각화: 대표자 연령대별 성별 분포 (자치구별 Facet)
windows(width = 10, height = 10)
ggplot(summary_data, aes(x = 대표자연령대, y = 사업체수, fill = 성별)) +
  geom_bar(stat = "identity", position = "dodge") +
  facet_wrap(~ 구, ncol = 5) +
  labs(
    title = "자치구별 대표자 성별·연령대별 사업체 수",
    x = "대표자 연령대",
    y = "사업체 수",
    fill = "성별"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.text.x = element_text(angle = 45, hjust = 1),
    strip.text = element_text(size = 12, face = "bold")
  )

# 교재 104 페이지
################################################
# 9. 자치구별 성별/연령대별 특성성 분석하기
################################################

# 필요한 패키지
library(dplyr)
library(tidyr)
library(ggplot2)

# 9-1. 전체 성별 비율 구하기
gender_total <- Business_Survey %>%
  count(대표자성별) %>%
  mutate(전체비율 = n / sum(n))

# 9-2. 자치구별 성별 비율 구하기
gender_by_gu <- Business_Survey %>%
  count(구, 대표자성별) %>%
  group_by(구) %>%
  mutate(구별비율 = n / sum(n)) %>%
  ungroup()

# 9-3. 평균과의 차이 계산 (절대값)
gender_diff <- gender_by_gu %>%
  left_join(gender_total %>% select(대표자성별, 전체비율), by = "대표자성별") %>%
  mutate(차이 = abs(구별비율 - 전체비율))

# 9-4. 자치구별 차이 합산 (총 편차)
gender_diff_summary <- gender_diff %>%
  group_by(구) %>%
  summarise(총편차 = sum(차이)) %>%
  arrange(desc(총편차))

# 결과 출력
print(gender_diff_summary)

# 9-5. 전체 연령대 비율
age_total <- Business_Survey %>%
  count(대표자연령대) %>%
  mutate(전체비율 = n / sum(n))

# 9-6. 구별 연령대 비율
age_by_gu <- Business_Survey %>%
  count(구, 대표자연령대) %>%
  group_by(구) %>%
  mutate(구별비율 = n / sum(n)) %>%
  ungroup()

# 9-7. 차이 계산 및 요약
age_diff <- age_by_gu %>%
  left_join(age_total %>% select(대표자연령대, 전체비율), by = "대표자연령대") %>%
  mutate(차이 = abs(구별비율 - 전체비율))

age_diff_summary <- age_diff %>%
  group_by(구) %>%
  summarise(총편차 = sum(차이)) %>%
  arrange(desc(총편차))

# 결과 출력
print(age_diff_summary)
windows(width = 10, height = 10)
ggplot(gender_diff_summary, aes(x = reorder(구, -총편차), y = 총편차)) +
  geom_bar(stat = "identity", fill = "tomato") +
  labs(
    title = "자치구별 대표자 성별비율 편차",
    x = "자치구",
    y = "전체 평균 대비 편차"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.text.x = element_text(size = 12, angle = 45, hjust = 1),
    axis.text.y = element_text(size = 12)
  )

windows(width = 10, height = 10)
ggplot(age_diff_summary, aes(x = reorder(구, -총편차), y = 총편차)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  labs(
    title = "자치구별 대표자 연령대 비율 편차",
    x = "자치구",
    y = "전체 평균 대비 편차"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.text.x = element_text(size = 12, angle = 45, hjust = 1),
    axis.text.y = element_text(size = 12)
  )

# 교재 106 페이지
# 패키지
library(dplyr)
library(ggplot2)
library(showtext)

# 9-8. 전체 평균 성별 비율 계산
gender_total <- Business_Survey %>%
  count(대표자성별) %>%
  mutate(
    성별 = case_when(
      대표자성별 == "1" ~ "남",
      대표자성별 == "2" ~ "여"
    ),
    비율 = n / sum(n),
    구 = "전체평균"
  ) %>%
  select(구, 성별, 비율)

# 9-9. 자치구별 성별 비율
gender_by_gu <- Business_Survey %>%
  count(구, 대표자성별) %>%
  group_by(구) %>%
  mutate(
    비율 = n / sum(n),
    성별 = case_when(
      대표자성별 == "1" ~ "남",
      대표자성별 == "2" ~ "여"
    )
  ) %>%
  ungroup() %>%
  select(구, 성별, 비율)

# 9-10. 전체 데이터 결합
compare_data <- bind_rows(gender_total, gender_by_gu)

str(gender_by_gu)

# 9-11.자치구 편차 계산
# 1) gender_total에는 구 제거
gender_total_clean <- gender_total %>% select(-구) %>% rename(비율_전체 = 비율)

# 2) gender_by_gu → rename
deviation <- gender_by_gu %>%
  rename(비율_구 = 비율) %>%
  left_join(gender_total_clean, by = "성별") %>%
  group_by(구) %>%
  summarise(총편차 = sum(abs(비율_구 - 비율_전체)), .groups = "drop") %>%
  arrange(desc(총편차))

# 3) 정렬 순서 지정: "전체평균" → 금천구 → 나머지
ordered_gu <- c("전체평균", "금천구", deviation$구[deviation$구 != "금천구"])
compare_data$구 <- factor(compare_data$구, levels = ordered_gu)


# 4) 시각화
# 여성 전체 평균 비율만 추출
여성평균비율 <- gender_total %>% 
  filter(성별 == "여") %>% 
  pull(비율)  # 숫자만 추출

# 누적 막대그래프 + 흰색 수평선
windows(width = 15, height = 10)
ggplot(compare_data, aes(x = 구, y = 비율, fill = 성별)) +
  geom_bar(stat = "identity", position = "stack") +
  geom_hline(yintercept = 여성평균비율, color = "white", size = 1.5) +  # ✔ 흰색 선 추가
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  scale_fill_manual(values = c("남" = "#3498db", "여" = "#e74c3c")) +
  labs(
    title = "자치구별 대표자 성별 비율 (전체 여성 평균선 포함)",
    x = "자치구",
    y = "비율",
    fill = "성별"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 20, face = "bold", hjust = 0.5),
    axis.text.x = element_text(size = 10, angle = 45, hjust = 1),
    legend.text = element_text(size = 12)
  )

####
# 교재 108 페이지
library(dplyr)
library(ggplot2)
library(scales)

# 9-12. 연령대 라벨 부여
Business_Survey <- Business_Survey %>%
  mutate(
    연령대 = case_when(
      대표자연령대 == "1" ~ "20대 미만",
      대표자연령대 == "2" ~ "20대",
      대표자연령대 == "3" ~ "30대",
      대표자연령대 == "4" ~ "40대",
      대표자연령대 == "5" ~ "50대",
      대표자연령대 == "6" ~ "60대",
      대표자연령대 == "7" ~ "70대",
      대표자연령대 == "8" ~ "80대",
      대표자연령대 == "9" ~ "90대 이상",
      TRUE ~ NA_character_
    ),
    연령대 = factor(연령대, levels = c("20대 미만", "20대", "30대", "40대", "50대", "60대", "70대", "80대", "90대 이상"))
  )

# 1) 전체 평균 연령대별 비율
age_total <- Business_Survey %>%
  filter(!is.na(연령대)) %>%
  count(연령대) %>%
  mutate(
    구 = "전체평균",
    구비율 = n / sum(n),
    label = percent(구비율, accuracy = 1)  # 전체 평균은 항상 라벨 표시
  ) %>%
  select(구, 연령대, 구비율, label)

# 2) 자치구별 연령대별 비율
age_by_gu <- Business_Survey %>%
  filter(!is.na(구), !is.na(연령대)) %>%
  count(구, 연령대) %>%
  group_by(구) %>%
  mutate(구비율 = n / sum(n)) %>%
  ungroup()

# 3) 전체 평균과 비교해 "가장 높은 초과 연령대" 구별 추출
age_total_ratio <- age_total %>%
  select(연령대, 전체비율 = 구비율)

age_diff <- age_by_gu %>%
  left_join(age_total_ratio, by = "연령대") %>%
  mutate(차이 = 구비율 - 전체비율) %>%
  group_by(구) %>%
  filter(차이 == max(차이)) %>%
  slice(1) %>%
  ungroup() %>%
  select(구, 연령대, 구비율)

# 4) 자치구별 시각화용 데이터 생성
plot_data_gu <- age_by_gu %>%
  left_join(age_diff %>% rename(강조연령대 = 연령대, 강조비율 = 구비율), by = "구") %>%
  mutate(
    label = ifelse(연령대 == 강조연령대, percent(구비율, accuracy = 1), "")
  )

# 5) 전체 평균 + 구별 데이터 결합
plot_data <- bind_rows(age_total, plot_data_gu)

# 6) 자치구 순서 설정 (전체평균을 맨 앞으로)
gu_order <- c("전체평균", sort(unique(age_by_gu$구)))
plot_data$구 <- factor(plot_data$구, levels = gu_order)

windows(width = 15, height = 10)
ggplot(plot_data, aes(x = 구, y = 구비율, fill = 연령대)) +
  geom_col() +
  geom_text(
    aes(label = label),
    position = position_stack(vjust = 0.5),
    color = "black",
    size = 4,
    family = "SeoulNamsan"
  ) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  scale_fill_brewer(palette = "Paired") +
  labs(
    title = "자치구별 대표자 연령대 비율 (전체평균 포함, 평균 대비 높은 연령대 강조)",
    x = "자치구",
    y = "비율",
    fill = "연령대"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1),
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5)
  )

# 교재 110 페이지
################################################
# 10. 자치구별 산업특화 분석하기
################################################
# 패키지
library(dplyr)
library(tidyr)
library(ggplot2)
library(scales)
library(showtext)

# 데이터 준비

# 📌 Summary_Business_Survey 생성 스크립트
Summary_Business_Survey <- Business_Survey %>%
  group_by(
    조사기준년도,
    구,
    동,
    주사업_산업분류부호_대분류항목명,
    주사업_산업분류부호_중분류항목명,
    주사업_산업분류부호_소분류항목명,
    주사업_산업분류부호_세분류항목명,
    주사업_산업분류부호_세세분류항목명
  ) %>%
  summarise(n = n(), .groups = "drop") %>%
  arrange(조사기준년도, 구, 동, desc(n))

# 📌 컬럼명 정리 (rename)
names(Summary_Business_Survey) <- c(
  "년도", "자치구명", "동",
  "산업대분류", "산업중분류", "산업소분류", "산업세분류", "산업세세분류",
  "사업체수"
)

# ✅ 확인
str(Summary_Business_Survey)
head(Summary_Business_Survey)

# 복사본 만들기 (rename 필요 없음)
data <- Summary_Business_Survey


# -------------------------------------------
# 1️⃣ 자치구-산업별 사업체수 집계
# -------------------------------------------
df_LQ <- data %>%
  group_by(자치구명, 산업중분류) %>%
  summarise(사업체수 = sum(사업체수), .groups = "drop")

# -------------------------------------------
# 2️⃣ 전체 합계 (자치구별, 전체별)
# -------------------------------------------

# 자치구별 총 사업체수
df_total_gu <- df_LQ %>%
  group_by(자치구명) %>%
  summarise(구전체_사업체수 = sum(사업체수), .groups = "drop")

# 산업별 총 사업체수 (전체 합계)
df_total_industry <- df_LQ %>%
  group_by(산업중분류) %>%
  summarise(산업전체_사업체수 = sum(사업체수), .groups = "drop")

# 전체 총합
total_all <- sum(df_LQ$사업체수)

# -------------------------------------------
# 3️⃣ LQ 계산
# -------------------------------------------

df_LQ_final <- df_LQ %>%
  left_join(df_total_gu, by = "자치구명") %>%
  left_join(df_total_industry, by = "산업중분류") %>%
  mutate(
    구내_비중 = 사업체수 / 구전체_사업체수,
    전체_비중 = 산업전체_사업체수 / total_all,
    LQ = 구내_비중 / 전체_비중
  )

# -------------------------------------------
# 4️⃣ LQ >= 1 필터 + 상위 N개만 (선택)
# -------------------------------------------

# 예: LQ >= 1 + 상위 5개 산업만 표시
df_LQ_top <- df_LQ_final %>%
  filter(LQ >= 1) %>%
  group_by(자치구명) %>%
  slice_max(order_by = LQ, n = 5) %>%
  ungroup()

# -------------------------------------------
# 5️⃣ 히트맵 그리기
# -------------------------------------------

windows(width = 60, height = 30)

ggplot(df_LQ_top, aes(x = 자치구명, y = 산업중분류, fill = LQ)) +
  geom_tile(color = "white", linewidth = 0.5) +
  scale_fill_gradient(low = "#fee0d2", high = "#a50f15", name = "특화지수 (LQ)") +
  labs(
    title = "자치구별 산업 특화 분석 (LQ >= 1) - 상위 5개 업종",
    x = "자치구",
    y = "산업중분류"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
    axis.text.x = element_text(size = 12, angle = 45, hjust = 1),
    axis.text.y = element_text(size = 10),
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 11)
  )