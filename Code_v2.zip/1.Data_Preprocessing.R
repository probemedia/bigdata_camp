rm(list = ls())  # 모든 객체 삭제
gc()  # 메모리 정리
setwd("C:/Project/Data")

library(dplyr) 

##############################
# 1. CSV 파일 읽기
##############################

# 설명: '2023년 기준 사업체조사.csv' 파일을 읽어서 첫 번째 행을 변수명으로 인식하고, 
# Business_Survey라는 데이터프레임을 생성

Business_Survey <- read.csv("C:/Project/Data/서울시사업체조사결과정보(2023년 기준)/2023년 기준 사업체조사.csv", 
                            header = TRUE, fileEncoding = "utf-8")

sum(is.na(Business_Survey$MBZ_INDST_DIV_CD))
# 각 값의 문자 길이 확인
table(nchar(Business_Survey$MBZ_INDST_DIV_CD))

# 자리수 계산 후 4자리인 경우 앞에 "0" 추가
Business_Survey <- Business_Survey %>%
  mutate(MBZ_INDST_DIV_CD = ifelse(
    !is.na(MBZ_INDST_DIV_CD) & nchar(MBZ_INDST_DIV_CD) == 4,
    paste0("0", MBZ_INDST_DIV_CD),
    MBZ_INDST_DIV_CD
  ))

##############################
# 2. 엑셀 파일 읽기
##############################

library(readxl)
encoding_guide <- read_excel("C:/Project/Data/서울시사업체조사결과정보(2023년 기준)/2023년 기준 전국사업체조사 잠정 레이아웃(공통).xlsx", 
                             sheet = "부호화 지침서", col_names = TRUE)

# 설명: '부호화 지침서' 워크시트를 읽어 
# encoding_guide 데이터프레임을 생성, 첫 번째 행을 변수명으로 사용

region_classification <- read_excel("C:/Project/Data/서울시사업체조사결과정보(2023년 기준)/2023년 기준 전국사업체조사 잠정 레이아웃(공통).xlsx", 
                                    sheet = "행정구역 분류", skip = 2, col_names = TRUE)

# 4. Business_Survey의 AD_CD와 region_classification 소분류 값을 기준으로 조인
# 설명: Business_Survey의 AD_CD와 region_classification의 소분류 값을 기준으로 조인하여 
# 시도, 시군구, 읍면동 정보를 추가


#"표준산업분류(10차)" 워크시트 읽기 및 변수명 수정
industry_classification <- read_excel("C:/Project/Data/서울시사업체조사결과정보(2023년 기준)/2023년 기준 전국사업체조사 잠정 레이아웃(공통).xlsx", 
                                      sheet = "표준산업분류(10차)", skip = 2, col_names = TRUE)

colnames(industry_classification) <- c(
  "대분류코드", "대분류항목명",
  "중분류코드", "중분류항목명",
  "소분류코드", "소분류항목명",
  "세분류코드", "세분류항목명",
  "세세분류코드", "세세분류항목명")

duplicated_codes <- industry_classification %>%
  group_by(세세분류코드) %>%
  filter(n() > 1)
nrow(duplicated_codes)  # 중복 코드 수 확인



# install.packages("tidyr")
library(tidyr)

industry_classification <- industry_classification %>%
  fill(everything(), .direction = "down")

# fill() 함수는 지정한 열의 NA 값을 이전(위쪽) 행의 값으로 채우기
# everything()은 모든 열을 대상으로 지정함
# .direction = "down"은 위에서 아래 방향으로 채우겠다는 의미

##############################
# 3. 조인 수행
##############################

# 3-1. 행정구역분류 조인
Business_Survey <- merge(
  Business_Survey,
  region_classification[, c("소분류", "시도", "시군구", "읍면동")],
  by.x = "AD_CD",
  by.y = "소분류",
  all.x = TRUE
)

# 전체 건수
total_count <- nrow(Business_Survey)

# 매칭된 건수 (시도 열이 NA가 아닌 경우로 판단)
matched_count <- sum(!is.na(Business_Survey$시도))

# 매칭되지 않은 건수
unmatched_count <- sum(is.na(Business_Survey$시도))

# 결과 출력
cat("전체 건수:", total_count, "\n")
cat("매칭된 건수:", matched_count, "\n")
cat("매칭되지 않은 건수:", unmatched_count, "\n")

# 3-2. 산업대분류코드 유효성 검증증

Business_Survey$INDST_LCLS_CD <- as.character(Business_Survey$INDST_LCLS_CD)
valid_indst_lcls_cd <- industry_classification$대분류코드
Business_Survey$INDST_LCLS_CD <- ifelse(Business_Survey$INDST_LCLS_CD %in% valid_indst_lcls_cd, Business_Survey$INDST_LCLS_CD, NA)

# 전체 건수
total_count <- nrow(Business_Survey)

# 유효한 건수
valid_count <- sum(!is.na(Business_Survey$INDST_LCLS_CD))

# 유효하지 않은 건수
invalid_count <- sum(is.na(Business_Survey$INDST_LCLS_CD))

# 결과 출력
cat("전체 건수:", total_count, "\n")
cat("유효한 건수:", valid_count, "\n")
cat("유효하지 않은 건수:", invalid_count, "\n")

# 3-3. 주사업_산업분류부호 유효성 점검
Business_Survey$MBZ_INDST_DIV_CD  <- as.character(Business_Survey$MBZ_INDST_DIV_CD)

valid_mbz_indst_div_cd <- industry_classification$세세분류코드
Business_Survey$MBZ_INDST_DIV_CD <- ifelse(Business_Survey$MBZ_INDST_DIV_CD %in% valid_mbz_indst_div_cd, 
                                           Business_Survey$MBZ_INDST_DIV_CD, NA)


# 전체 건수
total_count <- nrow(Business_Survey)

# 유효한 건수
valid_count <- sum(!is.na(Business_Survey$MBZ_INDST_DIV_CD))

# 유효하지 않은 건수
invalid_count <- sum(is.na(Business_Survey$MBZ_INDST_DIV_CD))

# 결과 출력
cat("전체 건수:", total_count, "\n")
cat("유효한 건수:", valid_count, "\n")
cat("유효하지 않은 건수:", invalid_count, "\n")


# 유효하지 않은 레코드 제거 (MBZ_INDST_DIV_CD가 NA인 행 삭제)
Business_Survey <- Business_Survey[!is.na(Business_Survey$MBZ_INDST_DIV_CD), ]

cat("유효한 MBZ_INDST_DIV_CD만 남은 전체 건수:", nrow(Business_Survey), "\n")

# 3-4. MBZ_INDST_DIV_CD 기준으로 조인하여 산업정보 추가
# 산업정보 조인 (MBZ_INDST_DIV_CD 기준)

# install.packages("data.table")  # 처음 한 번만
library(data.table)

# data.frame → data.table로 변환
dt_survey <- as.data.table(Business_Survey)
dt_industry <- as.data.table(industry_classification)

dt_industry <- unique(dt_industry, by = "세세분류코드")

# 키 설정 (조인 속도 향상)
setkey(dt_survey, MBZ_INDST_DIV_CD)
setkey(dt_industry, 세세분류코드)

# 조인 수행: 왼쪽 기준 (Business_Survey 유지)
dt_merged <- dt_industry[dt_survey, on = .(세세분류코드 = MBZ_INDST_DIV_CD)]

Business_Survey <- as.data.frame(dt_merged)

# 이후 열 이름 바꿔주기 (원래 조인 기준도 보존하고 싶다면)
names(Business_Survey)[names(Business_Survey) == "MBZ_INDST_DIV_CD"] <- "세세분류코드"


# 전체 건수
total_count <- nrow(Business_Survey)

# 매칭된 건수 (예: '세세분류항목명' 컬럼이 NA가 아닌 경우)
matched_count <- sum(!is.na(Business_Survey$세세분류항목명))

# 매칭되지 않은 건수
unmatched_count <- sum(is.na(Business_Survey$세세분류항목명))

# 결과 출력
cat("전체 건수:", total_count, "\n")
cat("매칭된 건수:", matched_count, "\n")
cat("매칭되지 않은 건수:", unmatched_count, "\n")

str(Business_Survey)


##############################
# 4. 변수 타입 변경
##############################

# 4-1. 범주형 변수로 변경
categorical_columns <- c("AD_CD", "RPRS_SD_CD", "RPRS_GNR", "ORG_FORM_CD", "ESTM_DIV_CD","INDST_LCLS_CD", 
                         "대분류코드","중분류코드", "소분류코드", "세분류코드" , "세세분류코드")
Business_Survey[categorical_columns] <- lapply(Business_Survey[categorical_columns], as.factor)

# 4-2. 나머지 변수는 숫자형으로 변경하고 Null을 0으로 대체
numerical_columns <- setdiff(names(Business_Survey), categorical_columns)
Business_Survey[numerical_columns] <- lapply(Business_Survey[numerical_columns], function(x) ifelse(is.na(x), 0, x))

cat("전체 건수:", total_count, "\n")


# 4-3. 대표자성별, 대표자연령대, 조직형태, 사업체구분 값 점검
# 대표자성별 (RPRS_SD_CD) 유효성 점검
valid_gender <- Business_Survey %>% filter(RPRS_SD_CD %in% c(1, 2))
invalid_gender <- Business_Survey %>% filter(!RPRS_SD_CD %in% c(1, 2))


# 대표자연령대 (RPRS_GNR) 유효성 점검
valid_age <- Business_Survey %>% filter(RPRS_GNR %in% 1:9)
invalid_age <- Business_Survey %>% filter(!RPRS_GNR %in% 1:9)

# 조직형태 (ORG_FORM_CD) 유효성 점검
valid_org <- Business_Survey %>% filter(ORG_FORM_CD %in% 1:5)
invalid_org <- Business_Survey %>% filter(!ORG_FORM_CD %in% 1:5)

# 사업체구분(ESTM_DIV_CD) 유효성 점검
valid_biz <- Business_Survey %>% filter(ESTM_DIV_CD %in% 1:3)
invalid_biz <- Business_Survey %>% filter(!ESTM_DIV_CD %in% 1:3)


cat("✅ 대표자성별 유효:", nrow(valid_gender), " / 무효:", nrow(invalid_gender), "\n")
cat("✅ 대표자연령대 유효:", nrow(valid_age), " / 무효:", nrow(invalid_age), "\n")
cat("✅ 조직형태 유효:", nrow(valid_org), " / 무효:", nrow(invalid_org), "\n")
cat("✅ 조사업체 구분 유효:", nrow(valid_biz), " / 무효:", nrow(invalid_biz), "\n")
                                              
# write.csv(invalid_gender, "invalid_RPRS_SD_CD.csv", row.names = FALSE)
# write.csv(invalid_age, "invalid_RPRS_GNR.csv", row.names = FALSE)
# write.csv(invalid_org, "invalid_ORG_FORM_CD.csv", row.names = FALSE)
# write.csv(invalid_biz, "invalid_BIZ_FORM_CD.csv", row.names = FALSE)

# Business_Survey 변수명 수정
colnames(Business_Survey)[1:40] <- c(
  "주사업_산업분류부호_대분류코드","주사업_산업분류부호_대분류항목명",
  "주사업_산업분류부호_중분류코드","주사업_산업분류부호_중분류항목명",
  "주사업_산업분류부호_소분류코드","주사업_산업분류부호_소분류항목명",
  "주사업_산업분류부호_세분류코드","주사업_산업분류부호_세분류항목명", 
  "주사업_산업분류부호_세세분류코드","주사업_산업분류부호_세세분류항목명",
  "행정구역분류부호","조사기준년도","대표자성별","대표자연령대",
  "창설연월_창설년도","창설연월_창설월","조직형태","사업체구분","산업대분류",
  "종사자수_계_자영업자","종사자수_남_자영업자","종사자수_여_자영업자",
  "종사자수_계_무급가족종사자","종사자수_남_무급가족종사자","종사자수_여_무급가족종사자",
  "종사자수_계_상용근로자","종사자수_남_상용근로자","종사자수_여_상용근로자",
  "종사자수_계_임시및일용근로자","종사자수_남_임시및일용근로자","종사자수_여_임시및일용근로자",
  "종사자수_계_기타종사자","종사자수_남_기타종사자","종사자수_여_기타종사자",
  "종사자수_계_합계","종사자수_남_합계","종사자수_여_합계","시","구","동")

str(Business_Survey)

Business_Survey <- Business_Survey[, c(
  "조사기준년도",
  "행정구역분류부호",
  "시",
  "구",
  "동",
  "대표자성별",
  "대표자연령대",
  "창설연월_창설년도",
  "창설연월_창설월",
  "조직형태",
  "사업체구분",
  # "산업대분류",
  "주사업_산업분류부호_대분류코드",
  "주사업_산업분류부호_대분류항목명",
  "주사업_산업분류부호_중분류코드",
  "주사업_산업분류부호_중분류항목명",
  "주사업_산업분류부호_소분류코드",
  "주사업_산업분류부호_소분류항목명",
  "주사업_산업분류부호_세분류코드",
  "주사업_산업분류부호_세분류항목명",
  "주사업_산업분류부호_세세분류코드",
  "주사업_산업분류부호_세세분류항목명",
  "종사자수_계_자영업자",
  "종사자수_남_자영업자",
  "종사자수_여_자영업자",
  "종사자수_계_무급가족종사자",
  "종사자수_남_무급가족종사자",
  "종사자수_여_무급가족종사자",
  "종사자수_계_상용근로자",
  "종사자수_남_상용근로자",
  "종사자수_여_상용근로자",
  "종사자수_계_임시및일용근로자",
  "종사자수_남_임시및일용근로자",
  "종사자수_여_임시및일용근로자",
  "종사자수_계_기타종사자",
  "종사자수_남_기타종사자",
  "종사자수_여_기타종사자",
  "종사자수_계_합계",
  "종사자수_남_합계",
  "종사자수_여_합계"
)]

# 7. 결과 파일 저장
save(Business_Survey, file = "C:/Project/Data/Business_Survey_Base.Rdata")

# 설명: 최종 결과를 "Business_Survey_Base.Rdata" 파일로 저장
