
# readxl 패키지 설치 및 로드하기(p.157)
# install.packages('readxl')
# install.packages('writexl')
# install.packages("xlsx")
# install.packages("readxl")  # 한 번만 설치하면 됨
# install.packages("forcats")   # 최초 1회 설치 (이미 했다면 생략)


library(readxl)
library(writexl)
library(dplyr)
library(readxl)
library(forcats)
library(data.table)
library(openxlsx)  # 엑셀 저장용

rm(list=ls())
setwd("C:/Project/Data")

# 저장 경로
save_path <- "C:/Project/Data/"

load("C:/Project/Data/Business_Survey_5Years.RData")
str(Business_Survey)

# 산업 분류명: 괄호 제거 + 다중 공백 제거 + 앞뒤 공백 제거
Business_Survey <- Business_Survey %>%
  mutate(
    MBZ_INDST_DIV_NAME = gsub("\\s+", " ", gsub("\\(.*?\\)", "", MBZ_INDST_DIV_NAME)) %>% trimws(),
    MBZ_INDST_MID_NAME = gsub("\\s+", " ", gsub("\\(.*?\\)", "", MBZ_INDST_MID_NAME)) %>% trimws(),
    MBZ_INDST_SML_NAME = gsub("\\s+", " ", gsub("\\(.*?\\)", "", MBZ_INDST_SML_NAME)) %>% trimws(),
    MBZ_INDST_CLS_NAME = gsub("\\s+", " ", gsub("\\(.*?\\)", "", MBZ_INDST_CLS_NAME)) %>% trimws(),
    MBZ_INDST_DTL_NAME = gsub("\\s+", " ", gsub("\\(.*?\\)", "", MBZ_INDST_DTL_NAME)) %>% trimws()
  )


# 고유값 추출
industry_hierarchy <- Business_Survey %>%
  select(
    MBZ_INDST_DIV_CD, MBZ_INDST_DIV_NAME,
    MBZ_INDST_MID_NAME,
    MBZ_INDST_SML_NAME,
    MBZ_INDST_CLS_NAME,
    MBZ_INDST_DTL_NAME
  ) %>%
  distinct() %>%
  arrange(MBZ_INDST_DIV_CD, MBZ_INDST_MID_NAME, MBZ_INDST_SML_NAME, MBZ_INDST_CLS_NAME, MBZ_INDST_DTL_NAME)

# 확인
head(industry_hierarchy)

# 교재 170 페이지
######################################################
# 1. 서울시 전체 연도별 종사자수 및 평균종사자수 추이
######################################################

# 산업대분류_산업분류부호	MBZ_INDST_DIV_NAME (농업 임업 및 어업)
# 산업중분류_산업분류부호	MBZ_INDST_MID_NAME (농업)
# 산업소분류_산업분류부호	MBZ_INDST_SML_NAME (작물 재배업)
# 산업세분류_산업분류부호 MBZ_INDST_CLS_NAME (채소, 화훼작물 및 종묘 재배업)
# 산업세세분류_산업분류부호 MBZ_INDST_DTL_NAME (종자 및 묘목 생산업)

library(ggplot2)

# install.packages("showtext")
library(showtext)

# 폰트 등록
font_add(family = "SeoulNamsan", regular = "C:/Windows/Fonts/SeoulNamsanL.ttf")

# showtext 활성화 (그래프에 적용되도록)
showtext_auto()


str(Business_Survey)

Summary_Business_Survey <- Business_Survey %>%
  group_by(
    SURV_BASE_YEAR,
    Gu_Name,
    MBZ_INDST_DIV_NAME,
    MBZ_INDST_DIV_CD,
    MBZ_INDST_MID_NAME,
    MBZ_INDST_SML_NAME,
    MBZ_INDST_CLS_NAME,
    MBZ_INDST_DTL_NAME,
    RPRS_SD_CD,
    RPRS_GNR,
    ORG_FORM_CD,
    ESTM_DIV_CD
  ) %>%
  summarise(
    n = n(),
    sum_SLFM_SUM = sum(SURV_PHS_SLFM_SUM, na.rm = TRUE),
    sum_SLFM_MAN_CNT = sum(SURV_PHS_SLFM_MAN_CNT, na.rm = TRUE),
    sum_SLFM_WMAN_CNT = sum(SURV_PHS_SLFM_WMAN_CNT, na.rm = TRUE),
    sum_UPF_SUM = sum(SURV_PHS_UPF_SUM, na.rm = TRUE),
    sum_UPF_MAN_CNT = sum(SURV_PHS_UPF_MAN_CNT, na.rm = TRUE),
    sum_UPF_WMAN_CNT = sum(SURV_PHS_UPF_WMAN_CNT, na.rm = TRUE),
    sum_CE_SUM = sum(SURV_PHS_CE_SUM, na.rm = TRUE),
    sum_CE_MAN_CNT = sum(SURV_PHS_CE_MAN_CNT, na.rm = TRUE),
    sum_CE_WMAN_CNT = sum(SURV_PHS_CE_WMAN_CNT, na.rm = TRUE),
    sum_TMPR_DALY_SUM = sum(SURV_PHS_TMPR_DALY_SUM, na.rm = TRUE),
    sum_TMPR_DALY_MAN_CNT = sum(SURV_PHS_TMPR_DALY_MAN_CNT, na.rm = TRUE),
    sum_TMPR_DALY_WMAN_CNT = sum(SURV_PHS_TMPR_DALY_WMAN_CNT, na.rm = TRUE),
    sum_OTR_SUM = sum(SURV_PHS_OTR_SUM, na.rm = TRUE),
    sum_OTR_MAN_CNT = sum(SURV_PHS_OTR_MAN_CNT, na.rm = TRUE),
    sum_OTR_WMAN_CNT = sum(SURV_PHS_OTR_WMAN_CNT, na.rm = TRUE),
    sum_WOKE_SUM = sum(SURV_PHS_WOKE_SUM, na.rm = TRUE),
    sum_MAN_SUM = sum(SURV_PHS_MAN_SUM, na.rm = TRUE),
    sum_WMAN_SUM = sum(SURV_PHS_WMAN_SUM, na.rm = TRUE)
  )

str(Summary_Business_Survey)
# write.csv(Summary_Business_Survey, "Summary_Business_Survey.csv", row.names = FALSE)

# 교재 171 페이지

library(ggplot2)
library(scales)
library(readr)

# -------------------------------------------
# 1️⃣ Summary_Business_Survey → 연도별 집계
# -------------------------------------------

df_summary <- Summary_Business_Survey %>%
  group_by(SURV_BASE_YEAR) %>%
  summarise(
    사업체수 = sum(n),
    종사자수 = sum(sum_WOKE_SUM),
    평균종사자수 = 종사자수 / 사업체수
  ) %>%
  arrange(SURV_BASE_YEAR) %>%
  mutate(
    # 전년 대비 증감률 계산
    사업체수_증감률 = (사업체수 / lag(사업체수) - 1) * 100,
    종사자수_증감률 = (종사자수 / lag(종사자수) - 1) * 100
  )

# 확인
print(df_summary)

# -------------------------------------------
# 2️⃣ 표 출력용 (포맷 적용)
# -------------------------------------------

df_summary_fmt <- df_summary %>%
  mutate(
    사업체수 = comma(사업체수),
    종사자수 = comma(종사자수),
    평균종사자수 = round(평균종사자수, 2),
    사업체수_증감률 = round(사업체수_증감률, 2),
    종사자수_증감률 = round(종사자수_증감률, 2)
  )

# 보기 좋게 출력
print(df_summary_fmt)

# -------------------------------------------
# 3️⃣ 그래프 그리기 (종사자수 + 평균종사자수)
# -------------------------------------------

# 원본 숫자용 복사
df_plot <- df_summary %>%
  mutate(
    종사자수_천명 = 종사자수 / 1000,
    평균종사자수 = 평균종사자수
  )

# 그리기
# 📌 3️⃣ 그래프 그리기 (종사자수 + 평균종사자수) - 개선 버전
windows(width = 10, height = 7)  # 윈도우 환경이면 창 크기 지정
ggplot(df_plot, aes(x = as.factor(SURV_BASE_YEAR))) +
  
  # 종사자수 → 막대그래프
  geom_bar(aes(y = 종사자수_천명), stat = "identity", fill = "skyblue", width = 0.7) +
  
  # 막대 위에 라벨 추가
  geom_text(aes(y = 종사자수_천명, label = comma(round(종사자수_천명, 0))),
            vjust = -0.5, size = 4, color = "black") +
  
  # 평균종사자수 → 선그래프
  # geom_line(aes(y = 평균종사자수 * 1000, group = 1), color = "orange", size = 1.2) +
  geom_line(aes(y = 평균종사자수 * 1000, group = 1), color = "orange", linewidth = 1.2) +

  
  # 선 위에 라벨 추가
  geom_text(aes(y = 평균종사자수 * 1000, label = round(평균종사자수, 2)),
            vjust = -1, size = 4, color = "orange") +
  
  # 축 설정 - Y축에 콤마 추가
  scale_y_continuous(
    name = "종사자수 (천명)",
    labels = comma,
    limits = c(0, 7000),  # 좌측 Y축 (단위: 천명)
    sec.axis = sec_axis(~ . / 1000, name = "평균종사자수 (명)", breaks = seq(0, 7, 1))  # 우측 Y축 (단위: 명)
  ) +
  
  labs(
    title = "연도별 종사자수 및 평균종사자수 추이",
    x = "연도",
    y = "종사자수 (천명)"
  ) +
  
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    axis.text.x = element_text(size = 12),
    axis.text.y = element_text(size = 12),
    axis.title.y = element_text(size = 14),
    axis.title.y.right = element_text(size = 14, color = "orange"),
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5)
  )

# 교재 173 페이지
######################################################
# 2. 서울시 전체 연도별 종사자 규모별 사업체수 추이
######################################################

library(dplyr)
library(tidyr)
library(ggplot2)
library(scales)

# ------------------------------------------------
# 1️⃣ 종사자구간 컬럼 추가
# ------------------------------------------------

Business_Survey <- Business_Survey %>%
  mutate(
    종사자구간 = case_when(
      SURV_PHS_WOKE_SUM >= 1 & SURV_PHS_WOKE_SUM <= 4   ~ "1~4인",
      SURV_PHS_WOKE_SUM >= 5 & SURV_PHS_WOKE_SUM <= 9   ~ "5~9인",
      SURV_PHS_WOKE_SUM >= 10 & SURV_PHS_WOKE_SUM <= 49 ~ "10~49인",
      SURV_PHS_WOKE_SUM >= 50 & SURV_PHS_WOKE_SUM <= 99 ~ "50~99인",
      SURV_PHS_WOKE_SUM >= 100 & SURV_PHS_WOKE_SUM <= 299 ~ "100~299인",
      SURV_PHS_WOKE_SUM >= 300 ~ "300인 이상",
      TRUE ~ "기타"
    )
  )

# ------------------------------------------------
# 2️⃣ 2020~2023 구간별 사업체수 + 증감률 계산
# ------------------------------------------------

# 집계
df_size_summary <- Business_Survey %>%
  filter(SURV_BASE_YEAR %in% c(2019, 2020, 2021, 2022, 2023)) %>%
  group_by(SURV_BASE_YEAR, 종사자구간) %>%
  summarise(사업체수 = n(), .groups = "drop") %>%
  arrange(SURV_BASE_YEAR, 종사자구간)

# 증감률 계산 (전년 대비 %)
df_size_summary <- df_size_summary %>%
  group_by(종사자구간) %>%
  arrange(SURV_BASE_YEAR) %>%
  mutate(
    증감률 = (사업체수 / lag(사업체수) - 1) * 100
  ) %>%
  ungroup()

# ------------------------------------------------
# 3️⃣ 표 형식 (wide 변환)
# ------------------------------------------------

df_size_summary$종사자구간 <- factor(df_size_summary$종사자구간,
                                levels = c("1~4인", "5~9인", "10~49인", "50~99인", "100~299인", "300인 이상"))

df_size_summary_wide <- df_size_summary %>%
  select(SURV_BASE_YEAR, 종사자구간, 사업체수) %>%
  pivot_wider(names_from = SURV_BASE_YEAR, values_from = 사업체수) %>%
  arrange(종사자구간)

# 확인
print(df_size_summary_wide)

library(tidyr)
library(ggplot2)
library(showtext)
# install.packages("ggrepel")
library(ggrepel)

showtext_auto()
theme_minimal(base_family = "SeoulNamsan")

# Wide -> Long 형태 변환 + 연도 2020~2023 필터링
df_plot <- df_size_summary_wide %>%
  pivot_longer(-종사자구간, names_to = "연도", values_to = "사업체수") %>%
  mutate(
    연도 = as.integer(연도),
    종사자구간 = factor(종사자구간, levels = c("1~4인", "5~9인", "10~49인", "50~99인", "100~299인", "300인 이상"))
  ) %>%
  filter(연도 >= 2019 & 연도 <= 2023) %>%
  mutate(연도 = as.factor(연도))  # 다시 factor로 변환


# 교재 174 페이지
# 막대그래프 그리기
windows(width = 10, height = 7) 
ggplot(df_plot, aes(x = 종사자구간, y = 사업체수, fill = 연도)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.9)) +
  geom_text(aes(label = comma(사업체수)),
            position = position_dodge(width = 0.9),
            vjust = -0.2,           # 더 띄워서 잘리지 않게
            angle = 45,             # 45도 회전
            hjust = 0,              # 왼쪽 정렬로 회전 텍스트 보기 좋게
            size = 3.2, color = "black") +
  labs(
    title = "종사자구간별 사업체수 (2019~2023년)",
    x = "종사자구간",
    y = "사업체수"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.text.x = element_text(angle = 0, vjust = 0.5, hjust = 0.5)
  ) +
  scale_y_continuous(labels = comma, expand = expansion(mult = c(0, 0.1)))

## TEMP
# ✅ 예시 1 : 상대비율(%) 그래프
# 각 구간 내 연도별 비율 계산
df_plot_pct <- df_plot %>%
  group_by(연도) %>%
  mutate(비율 = 사업체수 / sum(사업체수) * 100) %>%
  ungroup()  # 그룹 해제 (추후 그래프 등 작업 위해)

# 퍼센트 그래프
windows(width = 10, height = 7)
ggplot(df_plot_pct, aes(x = 연도, y = 비율, fill = 연도)) +
  geom_bar(stat = "identity") +
  facet_wrap(~ 종사자구간, scales = "free_y") +
  labs(title = "종사자구간별 사업체수 비율 변화 (2019~2023년)", 
       x = "연도", y = "비율 (%)") +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.text.x = element_text(size = 12),
    axis.text.y = element_text(size = 12)
  )

# ✅ 예시 2 : facet_wrap으로 구간별 분할 표시
windows(width = 12, height = 8)
ggplot(df_plot, aes(x = 연도, y = 사업체수, fill = 연도)) +
  geom_bar(stat = "identity") +
  facet_wrap(~ 종사자구간, scales = "free_y") +
  labs(title = "종사자구간별 사업체수 추이 (2019~2023년)", 
       x = "연도", y = "사업체수") +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.text.x = element_text(size = 12),
    axis.text.y = element_text(size = 12)
  ) +
  scale_y_continuous(labels = scales::comma)

# ✅ 예시 3 : 선그래프 (트렌드 강조)
windows(width = 12, height = 8)
ggplot(df_plot, aes(x = 연도, y = 사업체수, group = 종사자구간, color = 종사자구간)) +
  geom_line(linewidth = 1.2) +
  geom_point(size = 3) +
  labs(title = "종사자구간별 사업체수 추이 (2019~2023년)", 
       x = "연도", y = "사업체수") +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.text.x = element_text(size = 12),
    axis.text.y = element_text(size = 12)
  ) +
  scale_y_continuous(labels = scales::comma)


# 교재 175 페이지
# ✅ 예시 4상대비율 + 추세선 추가)

# 상대비율(%) 그래프 + 추세선 추가
windows(width = 12, height = 8)
ggplot(df_plot_pct, aes(x = 연도, y = 비율, group = 종사자구간, fill = 연도, color = 종사자구간)) +
  
  # 막대그래프 (비율)
  geom_bar(stat = "identity", alpha = 0.7) +
  
  # 추세선 추가
  geom_line(aes(group = 종사자구간), linewidth = 1.2) +
  
  # 점 추가 (optional, 가독성 ↑)
  geom_point(size = 3) +
  
  # Facet으로 구간별 분리
  facet_wrap(~ 종사자구간, scales = "free_y") +
  
  geom_text(aes(label = sprintf("%.2f%%", 비율)),  # 소수점 2자리 + % 표시
            vjust = -0.5,
            size = 3,
            color = "black",
            position = position_dodge(width = 0.9)) +
  
  # 라벨/테마
  labs(title = "종사자구간별 사업체수 비율 변화 (2019~2023년)", 
       x = "연도", y = "비율 (%)") +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.text.x = element_text(size = 12),
    axis.text.y = element_text(size = 12),
    legend.position = "none"  # 범례 숨기기 (facet에 이미 구간이 있음)
  )

## TEMP

# 1️⃣ df_pie 다시 만들기
df_pie <- df_size_summary_wide %>%
  pivot_longer(-종사자구간, names_to = "연도", values_to = "사업체수") %>%
  mutate(
    연도 = as.integer(연도),
    종사자구간 = factor(종사자구간, levels = c("1~4인", "5~9인", "10~49인", "50~99인", "100~299인", "300인 이상"))
  ) %>%
  filter(연도 >= 2019 & 연도 <= 2023) %>%
  mutate(연도 = as.factor(연도)) %>%
  group_by(연도) %>%
  mutate(
    비율 = 사업체수 / sum(사업체수),
    cumulative = cumsum(비율),
    midpoint = cumulative - 비율 / 2,
    label_text = paste0(round(비율 * 100, 1), "%")
  )

# my_theme 정의
my_theme <- theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.text = element_blank(),            # ⚠️ 축 글자 지움
    axis.title = element_blank(),           # ⚠️ 축 제목 지움
    panel.grid = element_blank(),
    strip.text = element_text(size = 14, face = "bold"),
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 11)
  )

my_theme_line <- theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.text.x = element_text(size = 14, angle = 0, vjust = 0.5, hjust = 0.5),  # ⭐ X축 라벨 추가 + 정렬
    axis.text.y = element_text(size = 12),
    axis.title.x = element_text(size = 13),
    axis.title.y = element_text(size = 13),
    panel.grid.major = element_line(color = "grey90"),
    panel.grid.minor = element_blank(),
    strip.text = element_text(size = 14, face = "bold"),
    legend.title = element_text(size = 12),
    legend.text = element_text(size = 11)
  )


# 2️⃣ 도넛차트 (그대로 사용)
windows(width = 10, height = 7) 
ggplot(df_pie, aes(x = 2, y = 비율, fill = 종사자구간)) +
  geom_bar(stat = "identity", width = 1, color = "white") +
  coord_polar("y", start = pi/3) +
  geom_text_repel(aes(y = midpoint, label = ifelse(비율 >= 0.01, label_text, "")),
                  nudge_x = 0.5, show.legend = FALSE, size = 4, family = "SeoulNamsan") +
  xlim(0.5, 2.5) +
  facet_wrap(~연도) +
  labs(title = "연도별 종사자구간별 사업체수 비율 (2019~2023년)", fill = "종사자구간") +
  my_theme +
  scale_fill_brewer(palette = "Set3")

# 교재 179 페이지
######################################################
# 3. 서울시 전체 산업별 사업체수 추이
######################################################

# ✅ 기본 분석 흐름 (산업대분류별 연도별 변화)
# 필요한 라이브러리
library(dplyr)
library(ggplot2)
library(scales)
library(showtext)
# install.packages("tidytext")
library(tidytext)

# 폰트 자동 적용
showtext_auto()
theme_set(theme_minimal(base_family = "SeoulNamsan"))

# 1️⃣ 산업대분류별 연도별 집계
df_industry_trend <- Summary_Business_Survey %>%
  group_by(SURV_BASE_YEAR, MBZ_INDST_DIV_NAME) %>%
  summarise(사업체수 = sum(n), .groups = "drop") %>%
  arrange(SURV_BASE_YEAR, desc(사업체수))

# 확인
head(df_industry_trend)

# 3-1 연도별 대분류별 사업체수 변화 분석

# 2️⃣ 가로막대 + 정렬 반대 (사업체수 많은 순 위쪽)
windows(width = 15, height = 10)
ggplot(df_industry_trend, aes(x = reorder(MBZ_INDST_DIV_NAME, 사업체수), y = 사업체수, fill = as.factor(SURV_BASE_YEAR))) +
  geom_bar(stat = "identity", position = "dodge") +
  coord_flip() +  # 가로막대
  labs(
    title = "산업대분류별 연도별 사업체수 변화",
    x = "산업대분류",
    y = "사업체수",
    fill = "연도"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
    axis.text.y = element_text(size = 11),
    axis.text.x = element_text(size = 12)
  ) +
  scale_y_continuous(labels = comma)

# 교재 181 페이지
###########################################
# 3-2 연도별 대분류별 사업체수 변화율 분석
# 증감률 계산
# 전년 대비 증감률 (%) = (올해 사업체수 / 전년도 사업체수 - 1) * 100

# 매년 변화율 계산
df_annual_change <- df_industry_trend %>%
  group_by(MBZ_INDST_DIV_NAME) %>%
  arrange(SURV_BASE_YEAR) %>%
  mutate(
    연도별증감률 = (사업체수 / lag(사업체수) - 1) * 100
  ) %>%
  ungroup()

# 2021~2023년만 추출 (2021년부터 변화율 계산 가능)
df_annual_change_filtered <- df_annual_change %>%
  filter(SURV_BASE_YEAR %in% c(2021, 2022, 2023))

df_annual_change_filtered_clean <- df_annual_change_filtered %>%
  filter(!is.na(연도별증감률))

# 그리고 그래프 그리기 → 동일
windows(width = 12, height = 8)
ggplot(df_annual_change_filtered_clean, 
       aes(x = reorder_within(MBZ_INDST_DIV_NAME, 연도별증감률, SURV_BASE_YEAR), 
           y = 연도별증감률, fill = 연도별증감률 > 0)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  facet_wrap(~ SURV_BASE_YEAR, ncol = 2, scales = "free_y") +  # ⭐ scales="free_y" 필수
  labs(
    title = "전년 대비 산업대분류별 연도별 사업체수 변화율 (2021~2023)",
    x = "산업대분류",
    y = "전년 대비 변화율 (%)"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
    axis.text.y = element_text(size = 12),
    axis.text.x = element_text(size = 12),
    strip.text = element_text(size = 14, face = "bold"),
    legend.position = "none"
  ) +
  scale_y_continuous(labels = scales::percent_format(scale = 1)) +
  scale_fill_manual(values = c("TRUE" = "steelblue", "FALSE" = "orange")) +
  scale_x_reordered()  # ⭐ 꼭 추가!


# 🚀 Step 1️⃣ 매년 증감률 계산

# 2021년 사업체수
df_2019 <- df_industry_trend %>%
  filter(SURV_BASE_YEAR == 2021) %>%
  select(MBZ_INDST_DIV_NAME, 사업체수) %>%
  rename(사업체수_2019 = 사업체수)

# 2023년 사업체수
df_2023 <- df_industry_trend %>%
  filter(SURV_BASE_YEAR == 2023) %>%
  select(MBZ_INDST_DIV_NAME, 사업체수) %>%
  rename(사업체수_2023 = 사업체수)

# 2021-2023 누적 변화율 계산
df_cumulative_change <- df_2019 %>%
  inner_join(df_2023, by = "MBZ_INDST_DIV_NAME") %>%
  mutate(
    누적변화율 = (사업체수_2023 / 사업체수_2019 - 1) * 100
  ) %>%
  arrange(desc(abs(누적변화율)))

# 🚀 Step 2️⃣ 누적 변화율 그래프

# 그래프 그리기
windows(width = 12, height = 8)
ggplot(df_cumulative_change, aes(x = reorder(MBZ_INDST_DIV_NAME, 누적변화율), y = 누적변화율, fill = 누적변화율 > 0)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(
    title = "2021~2023년 누적 변화율 산업",
    x = "산업대분류",
    y = "누적 변화율 (%)"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
    axis.text.y = element_text(size = 12),
    axis.text.x = element_text(size = 12),
    legend.position = "none"
  ) +
  scale_y_continuous(labels = scales::percent_format(scale = 1)) +
  scale_fill_manual(values = c("TRUE" = "steelblue", "FALSE" = "orange"))

# 교재 184 페이지
################################################
# 4. 강남구 산업대분류별 분석하기(2019년도~ 2023년)
################################################

Summary_Business_Survey <- Business_Survey %>%
  group_by(SURV_BASE_YEAR, Gu_Name, MBZ_INDST_DIV_NAME ) %>%
  summarise(n = n(), .groups = "drop") %>%   # <- .groups는 그룹 해제 옵션(선택사항)
  arrange(SURV_BASE_YEAR, Gu_Name, MBZ_INDST_DIV_NAME , desc(n))

names(Summary_Business_Survey) <- c("년도", "자치구명", "산업대분류", "사업체수")

str(Summary_Business_Survey)
gangnam_trend_top <- Summary_Business_Survey %>%
                     filter(자치구명 == "강남구")

#####################
# 4-1 꺽은선 그래프
#####################
library(ggplot2)
library(dplyr)
library(scales)
library(ggrepel) # 라벨 중복 방지용
# 년도 factor 변환

gangnam_trend_top <- gangnam_trend_top %>%
  mutate(년도 = factor(년도, levels = c(2019, 2020, 2021, 2022, 2023)))

max_year <- max(as.numeric(as.character(gangnam_trend_top$년도)))

# 그래프
windows(width = 20.0, height = 10)
ggplot(gangnam_trend_top,
       aes(x = 년도, y = 사업체수, color = 산업대분류, group = 산업대분류)) +
  geom_line(size = 1) +
  geom_point(size = 2) +
  
  # 마지막 연도 값 라벨 추가
  geom_text(data = gangnam_trend_top %>% filter(as.numeric(as.character(년도)) == max_year),
            aes(label = comma(사업체수)),
            vjust = -1.2,
            size = 5,
            family = "SeoulNamsan") +
  
  geom_text_repel(data = gangnam_trend_top %>% filter(as.numeric(as.character(년도)) == max_year),
                  aes(label = 산업대분류),
                  hjust = 0,
                  direction = "y",
                  nudge_x = 0.3,
                  segment.color = "grey50",
                  size = 5,
                  family = "SeoulNamsan") +
  
  scale_x_discrete(
    labels = c("2019", "2020", "2021", "2022", "2023"),
    expand = expansion(add = c(0.1, 0.5))
  ) +
  
  scale_y_continuous(labels = comma) +
  
  labs(
    title = "연도별 산업대분류별 사업체수 변화 (강남구)",
    x = "년도",
    y = "사업체 수"
  ) +
  
  my_theme_line +  # 본인이 정의한 테마 객체
  theme(
    axis.text.x = element_text(size = 14, angle = 0, vjust = 0.5, hjust = 0.5),
    legend.position = "none"
  )

### 수정
library(dplyr)
library(ggplot2)
library(scales)
library(ggrepel)

# ✔️ 1. 상위 10개 산업 추출 (전체 합 기준)
top10_industries <- gangnam_trend_top %>%
  group_by(산업대분류) %>%
  summarise(총사업체수 = sum(사업체수)) %>%
  arrange(desc(총사업체수)) %>%
  slice_head(n = 10) %>%
  pull(산업대분류)

# 교재 185 페이지
# ✔️ 2. 상위 10개 산업만 필터링
gangnam_top10_trend <- gangnam_trend_top %>%
  filter(산업대분류 %in% top10_industries)

# ✔️ 3. factor levels 순서 정리
gangnam_top10_trend <- gangnam_top10_trend %>%
  mutate(년도 = factor(년도, levels = c(2019, 2020, 2021, 2022, 2023)))

max_year <- max(as.numeric(as.character(gangnam_top10_trend$년도)))

# ✔️ 4. 꺾은선 그래프 시각화
windows(width = 15, height = 8)

ggplot(gangnam_top10_trend,
       aes(x = 년도, y = 사업체수, color = 산업대분류, group = 산업대분류)) +
  
  geom_line(size = 1) +
  geom_point(size = 2) +
  
  # 마지막 연도 수치
  geom_text(data = gangnam_top10_trend %>% filter(as.numeric(as.character(년도)) == max_year),
            aes(label = comma(사업체수)),
            vjust = -0.8,
            size = 4,
            family = "SeoulNamsan") +
  
  # 산업명 라벨
  geom_text_repel(data = gangnam_top10_trend %>% filter(as.numeric(as.character(년도)) == max_year),
                  aes(label = 산업대분류),
                  hjust = 0,
                  nudge_x = 0.3,
                  direction = "y",
                  segment.color = "grey50",
                  size = 4,
                  family = "SeoulNamsan") +
  
  scale_x_discrete(
    expand = expansion(add = c(0.1, 0.7))  # 좌우 여백 확보
  ) +
  
  scale_y_continuous(labels = comma) +
  
  labs(
    title = "연도별 산업대분류별 사업체수 변화 (강남구) - 상위 10개 산업",
    x = "년도",
    y = "사업체 수"
  ) +
  
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    axis.text.x = element_text(size = 12),
    legend.position = "none"
  )

# 교재 187 페이지
##############
# 애니메이션
##############
setwd("C:/Project/Data")

# install.packages("gganimate")
# install.packages("gifski")        # gif 저장용
# install.packages("transformr")    # 부드러운 트랜지션용

library(ggplot2)
library(gganimate)
library(dplyr)
library(scales)
library(showtext)


# 주사업_산업분류부호	MBZ_INDST_DIV_NAME
# 산업중분류_산업분류부호	MBZ_INDST_MID_NAME
# 산업소분류_산업분류부호	MBZ_INDST_SML_NAME
# 산업세세분류_산업분류부호 MBZ_INDST_CLS_NAME

####################
# 강남구
####################

gangnam_trend <- Summary_Business_Survey %>%
  filter(자치구명 == "강남구") %>%
  group_by(년도, 산업대분류) %>%
  summarise(총사업체수 = sum(사업체수), .groups = "drop")

# 폰트 적용 (선택사항)
showtext_auto()
font_add(family = "SeoulNamsan", regular = "C:/Windows/Fonts/SeoulNamsanL.ttf")

gg_gangnam <- ggplot(gangnam_trend, aes(x = reorder(산업대분류, 총사업체수), y = 총사업체수, fill = 산업대분류)) +
  geom_col(show.legend = FALSE) +
  coord_flip() +  # 가로로 전환
  scale_y_continuous(labels = comma) +  # Y축 사업체수 콤마
  labs(
    title = '강남구 산업대분류별 사업체수 변화',
    subtitle = '년도: {closest_state}',    
    x = '산업대분류',
    y = '사업체 수'
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 16, face = "bold"),
    axis.text.y = element_text(size = 10)
  ) +
  transition_states(년도, transition_length = 2, state_length = 1) +
  ease_aes('linear')

# 애니메이션 실행 (플레이어 미리보기)
animate(gg_gangnam, width = 800, height = 600, fps = 10, duration = 8, renderer = gifski_renderer())

# gif로 저장
anim_save("강남구_산업대분류별_사업체수_변화.gif")


# 교재 189 페이지
################################################
# 4-2 산업중분류별 분석하기(2019년도~ 2023년)
################################################

# 폰트 설정
font_add(family = "SeoulNamsan", regular = "C:/Windows/Fonts/SeoulNamsanL.ttf")
showtext_auto()

# 데이터 준비

Summary_Business_Survey <- Business_Survey %>%
  # filter(SURV_BASE_YEAR == 2023) %>%    # <<== 필터 조건 추가!
  # group_by(SURV_BASE_YEAR, Gu_Name, Dong_Name, MBZ_INDST_CLS_NAME) %>%
  filter(Gu_Name == "강남구") %>%
  group_by(SURV_BASE_YEAR, Gu_Name, Dong_Name, 
           MBZ_INDST_DIV_NAME, MBZ_INDST_MID_NAME, MBZ_INDST_SML_NAME,
           MBZ_INDST_CLS_NAME, MBZ_INDST_DTL_NAME) %>%
  summarise(n = n(), .groups = "drop") %>%   # <- .groups는 그룹 해제 옵션(선택사항)
  arrange(SURV_BASE_YEAR, Gu_Name, Dong_Name, 
          MBZ_INDST_DIV_NAME, MBZ_INDST_MID_NAME, MBZ_INDST_SML_NAME,
          MBZ_INDST_CLS_NAME, MBZ_INDST_DTL_NAME, desc(n))

# 폰트 설정
font_add(family = "SeoulNamsan", regular = "C:/Windows/Fonts/SeoulNamsanL.ttf")
showtext_auto()

# 데이터 준비
data <- Summary_Business_Survey
names(data) <- c("년도", "자치구명", "동", 
                 "산업대분류","산업중분류","산업소분류","산업세분류","산업세세분류", "사업체수")

# 산업중분류별 사업체수 합계
middle_trend <- data %>%
  group_by(년도, 산업대분류, 산업중분류) %>%
  summarise(총사업체수 = sum(사업체수), .groups = "drop") %>%
  arrange(desc(년도), desc(총사업체수))

# Top 20 산업중분류 추출 (2023 기준)
middle_trend_top20 <- middle_trend %>%
  filter(년도 == "2023") %>%
  arrange(desc(총사업체수)) %>%
  slice(1:20) %>%
  pull(산업중분류)

# 전체년도에서 Top 20 대상 데이터 생성
middle_trend_top20_data <- middle_trend %>%
  filter(산업중분류 %in% middle_trend_top20)

# industry_order (전체년도 최대값 기준 정렬)
industry_order <- middle_trend_top20_data %>%
  group_by(산업중분류) %>%
  summarise(최대사업체수 = max(총사업체수)) %>%
  arrange(최대사업체수) %>%
  pull(산업중분류)

# 순서 적용
middle_trend_top20_data <- middle_trend_top20_data %>%
  mutate(산업중분류 = factor(산업중분류, levels = industry_order))

# 교재 190 페이지
# ================================
# ✅ 년도별 상위 5개 중분류만 선택
# ================================

gg_mid_trend_top20 <- ggplot(middle_trend_top20_data, aes(   # ⭐⭐⭐ 여기만 수정!!
  x = 산업중분류,
  y = 총사업체수,
  fill = 산업대분류
)) +
  geom_col(width = 0.7, show.legend = TRUE) +
  
  geom_text(aes(label = format(총사업체수, big.mark = ",", scientific = FALSE),
                hjust = ifelse(총사업체수 < 1000, 1.1, -0.1)),  # ⭐ 조건부 적용!
            size = 3.5,
            family = "SeoulNamsan") +
  
  coord_flip() +  # Y축이 산업중분류
  
  scale_y_continuous(labels = comma,
                     expand = expansion(mult = c(0, 0.1))) +
  
  labs(
    title = '강남구 산업중분류별 사업체수 변화 (상위 20)',
    subtitle = '년도: {closest_state}',
    x = '산업중분류',
    y = '사업체 수',
    fill = '산업대분류'
  ) +
  
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(face = "bold", size = 20, hjust = 0.5),
    plot.subtitle = element_text(size = 16, face = "bold"),
    
    axis.text.y = element_text(size = 10, hjust = 1, margin = margin(r = 10)),
    axis.text.x = element_text(size = 10),
    
    legend.position = "right",
    
    plot.margin = margin(t = 10, r = 30, b = 10, l = 20),   # ⭐ 하나만 남김
    
    plot.background = element_rect(color = NA),
    
    panel.background = element_blank(),
    
    clip = "off"
  ) +
  
  transition_states(년도, transition_length = 2, state_length = 1) +
  ease_aes('linear')

animate(
  gg_mid_trend_top20,
  width = 960,
  height = 768,
  fps = 10,
  duration = 10,
  renderer = gifski_renderer()
)
anim_save("강남구_산업중분류별_사업체수_TOP20.gif")

# 교재 192 페이지
################################################
# 4-3 산업소분류별 분석하기(2019년도~ 2023년)
################################################

# 데이터 준비
data <- Summary_Business_Survey
names(data) <- c("년도", "자치구명", "동", 
                 "산업대분류","산업중분류","산업소분류","산업세분류","산업세세분류", "사업체수")

# 산업소분류별 사업체수 합계
middle_trend <- data %>%
  group_by(년도, 산업대분류, 산업중분류, 산업소분류) %>%
  summarise(총사업체수 = sum(사업체수), .groups = "drop") %>%
  arrange(desc(년도), desc(총사업체수))

# 상위 50개 업종만 추출 (2023년 기준)
grouped_data <- data %>%
  group_by(년도, 산업소분류) %>%
  summarise(총사업체수 = sum(사업체수), .groups = "drop")

# 2023년도 필터 및 정렬
grouped_2023 <- grouped_data %>%
  filter(년도 == "2023") %>%
  arrange(desc(총사업체수))

top_50_records <- grouped_2023 %>%
  slice(1:50)


filtered_data <- middle_trend %>%
  filter(산업소분류 %in% top_50_records$산업소분류)

middle_trend_top50 <- filtered_data

industry_order <- middle_trend_top50 %>%
  filter(년도 == "2023") %>%
  arrange(총사업체수) %>%  # 내림차순 정렬
  pull(산업소분류)

middle_trend_top50 <- middle_trend_top50 %>%
  mutate(산업소분류 = factor(산업소분류, levels = industry_order))

gg_mid_trend_top50 <- ggplot(middle_trend_top50, aes(
  x = 산업소분류,
  y = 총사업체수,
  fill = 산업중분류
)) +
  geom_col(width = 0.7, show.legend = TRUE) +
  
  geom_text(aes(label = format(총사업체수, big.mark = ",", scientific = FALSE)),
            hjust = -0.1,
            size = 3.5,
            family = "SeoulNamsan") +
  
  coord_flip() +  # Y축이 산업중분류
  
  scale_y_continuous(labels = comma,
                     expand = expansion(mult = c(0, 0.1))) +
  
  labs(
    title = '강남구 산업소분류별 사업체수 변화 (상위 50)',
    subtitle = '년도: {closest_state}',
    x = '산업소분류',
    y = '사업체 수',
    fill = '산업중분류'
  ) +
  
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(face = "bold", size = 20, hjust = 0.5),
    plot.subtitle = element_text(size = 16, face = "bold"),
    
    axis.text.y = element_text(size = 10, hjust = 1, margin = margin(r = 10)),
    axis.text.x = element_text(size = 10),
    
    legend.position = "right",
    legend.title = element_text(face = "bold"),
    legend.text = element_text(size = 10)
     ) +
    guides(fill = guide_legend(ncol = 1)) +
  transition_states(년도, transition_length = 2, state_length = 1) +
  ease_aes('linear')

animate(
  gg_mid_trend_top50,
  width = 960,
  height = 768,
  fps = 10,
  duration = 10,
  renderer = gifski_renderer()
)

anim_save("강남구_산업소분류별_사업체수_TOP50.gif")

# 교재 195 페이지
################################################
# 4-4 산업세분류별 분석하기(2019년도~ 2023년)
################################################

# 데이터 준비
data <- Summary_Business_Survey
names(data) <- c("년도", "자치구명", "동", 
                 "산업대분류","산업중분류","산업소분류","산업세분류","산업세세분류", "사업체수")

# 산업세분류별 사업체수 합계
middle_trend <- data %>%
  group_by(년도, 산업대분류, 산업중분류, 산업소분류, 산업세분류) %>%
  summarise(총사업체수 = sum(사업체수), .groups = "drop") %>%
  arrange(desc(년도), desc(총사업체수))

# 상위 50개 업종만 추출 (2023년 기준)
grouped_data <- data %>%
  group_by(년도, 산업세분류) %>%
  summarise(총사업체수 = sum(사업체수), .groups = "drop")

# 2023년도 필터 및 정렬
grouped_2023 <- grouped_data %>%
  filter(년도 == "2023") %>%
  arrange(desc(총사업체수))

top_50_records <- grouped_2023 %>%
  slice(1:50)


filtered_data <- middle_trend %>%
  filter(산업세분류 %in% top_50_records$산업세분류)

middle_trend_top50 <- filtered_data

industry_order <- middle_trend_top50 %>%
  filter(년도 == "2023") %>%
  arrange(총사업체수) %>%  # 내림차순 정렬
  pull(산업세분류)

middle_trend_top50 <- middle_trend_top50 %>%
  mutate(
    산업세분류 = factor(산업세분류, levels = industry_order),
    산업소분류 = factor(산업소분류)  # <- factor 레벨 정리
  )

gg_mid_trend_top50 <- ggplot(middle_trend_top50, aes(
  x = 산업세분류,
  y = 총사업체수,
  fill = 산업소분류
)) +
  geom_col(width = 0.7, show.legend = TRUE) +
  
  geom_text(aes(label = format(총사업체수, big.mark = ",", scientific = FALSE)),
            hjust = -0.1,
            size = 3.5,
            family = "SeoulNamsan") +
  
  coord_flip() +
  
  scale_y_continuous(labels = comma,
                     expand = expansion(mult = c(0, 0.1))) +
  
  scale_fill_discrete(drop = TRUE) +
  
  labs(
    title = '강남구 산업세분류별 사업체수 변화 (상위 50)',
    subtitle = '년도: {closest_state}',
    x = '산업세분류',
    y = '사업체 수',
    fill = '산업소분류'
  ) +
  
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(face = "bold", size = 20, hjust = 0.5),
    plot.subtitle = element_text(size = 16, face = "bold"),
    
    axis.text.y = element_text(size = 10, hjust = 1, margin = margin(r = 10)),
    axis.text.x = element_text(size = 10),
    
    legend.position = "right",            # ✅ 우측 정렬
    legend.direction = "vertical",        # ✅ 세로 정렬 (기본값)
    legend.title = element_text(face = "bold"),
    legend.text = element_text(size = 8),
    
    legend.key.size = unit(0.8, "lines"), # ✅ 색상 박스 크기 축소
    # legend.spacing.x = unit(1.5, "cm"),   # ✅ 항목 간 X 간격 추가
    legend.spacing.y = unit(1.5, "cm")    # ✅ 항목 간 Y 간격 추가
  ) +
  
  guides(fill = guide_legend(ncol = 1)) +  
  transition_states(년도, transition_length = 2, state_length = 1) +
  ease_aes('linear')


animate(
  gg_mid_trend_top50,
  width = 1000,
  height = 800,
  fps = 10,
  duration = 10,
  renderer = gifski_renderer()
)

anim_save("강남구_산업세분류별_사업체수_TOP50.gif")

# 교재 198 페이지
################################################
# 4-5 산업세세분류별 분석하기(2019년도~ 2023년)
################################################
# 데이터 준비
data <- Summary_Business_Survey
names(data) <- c("년도", "자치구명", "동", 
                 "산업대분류","산업중분류","산업소분류","산업세분류","산업세세분류", "사업체수")

# 산업세세분류별 사업체수 합계
middle_trend <- data %>%
  group_by(년도, 산업대분류, 산업중분류, 산업소분류, 산업세분류, 산업세세분류) %>%
  summarise(총사업체수 = sum(사업체수), .groups = "drop") %>%
  arrange(desc(년도), desc(총사업체수))

# 상위 50개 업종만 추출 (2023년 기준)
grouped_data <- data %>%
  group_by(년도, 산업세세분류) %>%
  summarise(총사업체수 = sum(사업체수), .groups = "drop")

# 2023년도 필터 및 정렬
grouped_2023 <- grouped_data %>%
  filter(년도 == "2023") %>%
  arrange(desc(총사업체수))

top_50_records <- grouped_2023 %>%
  slice(1:50)


filtered_data <- middle_trend %>%
  filter(산업세세분류 %in% top_50_records$산업세세분류)

middle_trend_top50 <- filtered_data

industry_order <- middle_trend_top50 %>%
  filter(년도 == "2023") %>%
  arrange(총사업체수) %>%  # 내림차순 정렬
  pull(산업세세분류)

middle_trend_top50 <- middle_trend_top50 %>%
  mutate(
    산업세세분류 = factor(산업세세분류, levels = industry_order),
    산업세분류 = factor(산업세분류)  # <- factor 레벨 정리
  )

gg_mid_trend_top50 <- ggplot(middle_trend_top50, aes(
  x = 산업세세분류,
  y = 총사업체수,
  fill = 산업세분류
)) +
  geom_col(width = 0.7, show.legend = TRUE) +
  
  geom_text(aes(label = format(총사업체수, big.mark = ",", scientific = FALSE)),
            hjust = -0.1,
            size = 3.5,
            family = "SeoulNamsan") +
  
  coord_flip() +
  
  scale_y_continuous(labels = comma,
                     expand = expansion(mult = c(0, 0.1))) +
  
  scale_fill_discrete(drop = TRUE) +
  
  labs(
    title = '강남구 산업세세분류별 사업체수 변화 (상위 50)',
    subtitle = '년도: {closest_state}',
    x = '산업세세분류',
    y = '사업체 수',
    fill = '산업세분류'
  ) +
  
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(face = "bold", size = 20, hjust = 0.5),
    plot.subtitle = element_text(size = 16, face = "bold"),
    
    axis.text.y = element_text(size = 10, hjust = 1, margin = margin(r = 10)),
    axis.text.x = element_text(size = 10),
    
    legend.position = "right",            # ✅ 우측 정렬
    legend.direction = "vertical",        # ✅ 세로 정렬 (기본값)
    legend.title = element_text(face = "bold"),
    legend.text = element_text(size = 8),
    
    legend.key.size = unit(0.8, "lines"), # ✅ 색상 박스 크기 축소
    # legend.spacing.x = unit(1.5, "cm"),   # ✅ 항목 간 X 간격 추가
    legend.spacing.y = unit(1.5, "cm")    # ✅ 항목 간 Y 간격 추가
  ) +
  
  guides(fill = guide_legend(ncol = 1)) +  
  transition_states(년도, transition_length = 2, state_length = 1) +
  ease_aes('linear')


animate(
  gg_mid_trend_top50,
  width = 1000,
  height = 800,
  fps = 10,
  duration = 10,
  renderer = gifski_renderer()
)

anim_save("강남구_산업세세분류별_사업체수_TOP50.gif")



