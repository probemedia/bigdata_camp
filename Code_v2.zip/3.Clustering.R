rm(list = ls())  # 모든 객체 삭제
gc()  # 메모리 정리
setwd("C:/Project/Data/")

# 교재 125 페이지
##################################
# 1. 종사자수, 사업체수
##################################
# 1-1. Business_Survey_Base.Rdata 파일을 불러와서 데이터프레임 생성
load("C:/Project/Data/Business_Survey_Base.Rdata")

# 1-2. 전체 사업체 수, 종사자 수, 평균 종사자 수 계산
# 각 레코드는 하나의 사업체를 의미하므로, 사업체 수는 행의 개수
total_businesses <- nrow(Business_Survey)

# 종사자수_계_합계라는 컬럼명을 사용하여 종사자 수 합계 계산
total_employees <- sum(Business_Survey$종사자수_계_합계, na.rm = TRUE)

# 평균 종사자 수 계산
average_employees <- total_employees / total_businesses

# 결과 출력
cat("전체 사업체 수:", total_businesses, "\n")
cat("전체 종사자 수:", total_employees, "\n")
cat("평균 종사자 수:", round(average_employees, 2), "\n")


library(dplyr)
library(ggplot2)

# install.packages("showtext")
library(showtext)

# 폰트 등록
font_add(family = "SeoulNamsan", regular = "C:/Windows/Fonts/SeoulNamsanL.ttf")

# showtext 활성화 (그래프에 적용되도록)
showtext_auto()

# 교재 127 페이지
##########################################
# 2. 5대 권역권별 사업체/종사자 현황 분석
##########################################

library(dplyr)

# 2-1. 자치구 → 권역 매핑
region_mapping <- c(
  "종로구" = "도심권", "중구" = "도심권", "용산구" = "도심권",
  "성북구" = "동북권", "강북구" = "동북권", "도봉구" = "동북권",
  "노원구" = "동북권", "중랑구" = "동북권", "동대문구" = "동북권",
  "성동구" = "동북권", "광진구" = "동북권",
  "은평구" = "서북권", "서대문구" = "서북권", "마포구" = "서북권",
  "양천구" = "서남권", "강서구" = "서남권", "구로구" = "서남권",
  "금천구" = "서남권", "영등포구" = "서남권", "동작구" = "서남권",
  "관악구" = "서남권",
  "강남구" = "동남권", "서초구" = "동남권", "송파구" = "동남권", 
  "강동구" = "동남권"
)

# 2-2. 권역별 면적 (단위: ㎢)
region_area <- data.frame(
  권역 = c("도심권", "동북권", "서북권", "서남권", "동남권"),
  면적 = c(56, 171, 71, 162, 145)
)

# 2-3. 권역 지정
Business_Survey <- Business_Survey %>%
  mutate(권역 = region_mapping[구]) %>%
  filter(!is.na(권역))

# 2-4. 권역별 집계 + 밀도 및 평균 종사자 수 계산
region_summary <- Business_Survey %>%
  group_by(권역) %>%
  summarise(
    사업체수 = n(),
    종사자수 = sum(종사자수_계_합계, na.rm = TRUE)
  ) %>%
  left_join(region_area, by = "권역") %>%
  mutate(
    평균종사자수 = round(종사자수 / 사업체수, 2),
    사업체밀도 = round(사업체수 / 면적, 1),    # 개 / ㎢
    종사자밀도 = round(종사자수 / 면적, 1)     # 명 / ㎢
  ) %>%
  select(권역, 면적, 사업체수, 종사자수, 평균종사자수, 사업체밀도, 종사자밀도) %>%
  arrange(desc(사업체수))

# 2-5. 결과 출력
print(region_summary)


# 설치
# install.packages("writexl")

# 패키지 로드
library(writexl)

# 작업 디렉터리 설정
setwd("C:/Project/Data/")

# 엑셀 파일 저장 (파일명은 원하는 대로 변경 가능)
write_xlsx(region_summary, path = "권역별사업체종사자집계정보.xlsx")

# 교재 128 페이지
##########################################

library(dplyr)
library(tidyr)

# 2-6. 권역 및 산업별 사업체 수 집계
industry_Summary <- Business_Survey %>%
  filter(!is.na(권역), !is.na(주사업_산업분류부호_대분류항목명)) %>%
  group_by(권역,주사업_산업분류부호_대분류코드, 주사업_산업분류부호_대분류항목명) %>%
  summarise(사업체수 = n(), .groups = "drop") %>%
  group_by(권역) %>%
  ungroup()

# 2-7. wide format 테이블로 변환 (산업명을 행, 권역을 열)
industry_table <- industry_Summary %>%
  select(산업 = 주사업_산업분류부호_대분류항목명, 주사업_산업분류부호_대분류코드, 
         권역,사업체수 ) %>%
  pivot_wider(names_from = 권역, values_from = 사업체수) %>%
  arrange(주사업_산업분류부호_대분류코드)

# 2-8. 결과 출력
print(industry_table)

# 엑셀 파일 저장 (파일명은 원하는 대로 변경 가능)
write_xlsx(industry_table, path = "권역별사업체집계정보.xlsx")

# 교재 130 페이지
##########################################
# 3. 5대 권역별 산업별 사업체 분석
##########################################

# 3-1. 권역별 × 산업별 사업체 수 집계
industry_by_region <- Business_Survey %>%
  group_by(권역, 주사업_산업분류부호_대분류항목명) %>%
  summarise(사업체수 = n(), .groups = "drop") %>%
  arrange(권역, desc(사업체수))

# 결과 확인
print(industry_by_region)


library(ggplot2)
library(dplyr)
library(showtext)
library(scales)

# 3-2. 히트맵
library(dplyr)
# 권역 / 구 / 산업대분류별 사업체수 집계
heatmap_data <- Business_Survey %>%
  group_by(권역, 구, 주사업_산업분류부호_대분류항목명) %>%
  summarise(사업체수 = n()) %>%
  ungroup()

# 확인
print(heatmap_data)

# 권역 / 산업대분류별 사업체수 집계
heatmap_data_region <- Business_Survey %>%
  group_by(권역, 주사업_산업분류부호_대분류항목명) %>%
  summarise(사업체수 = n()) %>%
  ungroup()

# 권역 순서 지정 (factor로 순서 고정)
heatmap_data_region <- heatmap_data_region %>%
  mutate(권역 = factor(권역, levels = c("도심권", "동남권", "동북권", "서남권", "서북권")))

library(stringr)  # 문자열 처리용

# 산업대분류명에서 "첫 숫자" 추출 → 정렬용 변수 생성
heatmap_data_region <- heatmap_data_region %>%
  mutate(
    산업정렬번호 = as.numeric(str_extract(주사업_산업분류부호_대분류항목명, "\\d+"))
  ) %>%
  arrange(desc(산업정렬번호)) %>%
  mutate(
    주사업_산업분류부호_대분류항목명 = factor(주사업_산업분류부호_대분류항목명, 
                               levels = unique(주사업_산업분류부호_대분류항목명))
  )


# 세로 막대그래프 (산업별 + 권역별 비교)
windows(width = 18, height = 10)
ggplot(industry_by_region, aes(x = reorder(주사업_산업분류부호_대분류항목명, -사업체수), y = 사업체수, fill = 권역)) +
  geom_col(position = "dodge") +
  labs(
    title = "산업 대분류별 서울시 권역별 사업체 수 비교",
    x = "산업 대분류",
    y = "사업체 수",
    fill = "권역"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 24, face = "bold", hjust = 0.5, family = "SeoulNamsan"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 11, family = "SeoulNamsan"),
    axis.text.y = element_text(size = 11, family = "SeoulNamsan"),
    axis.title = element_text(size = 14, face = "bold", family = "SeoulNamsan"),
    legend.title = element_text(size = 13, family = "SeoulNamsan"),
    legend.text = element_text(size = 11, family = "SeoulNamsan")
  ) +
  scale_y_continuous(labels = scales::comma)

# 교재 132 페이지
##########################################
# 권역별 산업대분류 사업체수 Heatmap
# Heatmap (산업 대분류 Y축, 권역 X축)
##########################################

windows(width = 15, height = 10)
ggplot(heatmap_data_region, aes(x = 권역, y = 주사업_산업분류부호_대분류항목명, fill = 사업체수)) +
  geom_tile(color = "white") +
  scale_fill_gradient(low = "white", high = "tomato", labels = comma) +
  labs(
    title = "권역별 산업대분류 사업체수 Heatmap",
    x = "권역",
    y = "산업 대분류",
    fill = "사업체수"
  ) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    axis.text.x = element_text(angle = 0, hjust = 0.5),
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5)
  )

# 교재 133 페이지
# 3-3. 산업별 × 권역별 사업체 수

library(dplyr)
library(tidyr)

# 권역 및 산업별 사업체 수 집계
industry_Summary <- Business_Survey %>%
  filter(!is.na(권역), !is.na(주사업_산업분류부호_대분류항목명)) %>%
  group_by(권역,주사업_산업분류부호_대분류코드, 주사업_산업분류부호_대분류항목명) %>%
  summarise(사업체수 = n(), .groups = "drop") %>%
  group_by(권역) %>%
  ungroup()

# wide format 테이블로 변환 (산업명을 행, 권역을 열)
industry_table <- industry_Summary %>%
  select(산업 = 주사업_산업분류부호_대분류항목명, 주사업_산업분류부호_대분류코드, 권역,사업체수 ) %>%
  pivot_wider(names_from = 권역, values_from = 사업체수) %>%
  arrange(주사업_산업분류부호_대분류코드)

# 결과 출력
print(industry_table)
# 엑셀 파일 저장 (파일명은 원하는 대로 변경 가능)
write_xlsx(industry_table, path = "권역별사업체집계정보.xlsx")

# 교재 135 페이지
##########################################
# 입지계수를 이용한 권역별 산업대분류 분석
##########################################

library(dplyr)
library(tidyr)

# 산업별 × 권역별 사업체 수 + 구성비
industry_by_region <- Business_Survey %>%
  filter(!is.na(권역), !is.na(주사업_산업분류부호_대분류항목명)) %>%
  group_by(권역, 산업 = 주사업_산업분류부호_대분류항목명) %>%
  summarise(사업체수 = n(), .groups = "drop") %>%
  group_by(권역) %>%
  mutate(
    권역내_구성비 = 사업체수 / sum(사업체수)
  ) %>%
  ungroup()

# 전체(서울시) 산업별 구성비 계산
industry_total <- Business_Survey %>%
  filter(!is.na(주사업_산업분류부호_대분류항목명)) %>%
  group_by(산업 = 주사업_산업분류부호_대분류항목명,주사업_산업분류부호_대분류코드) %>%
  summarise(전체_사업체수 = n(), .groups = "drop") %>%
  mutate(
    전체_구성비 = 전체_사업체수 / sum(전체_사업체수)
  )

# 입지계수 계산: 권역별 구성비 / 전체 구성비
lq_table <- industry_by_region %>%
  left_join(industry_total, by = "산업") %>%
  mutate(
    입지계수 = round(권역내_구성비 / 전체_구성비, 3)
  ) %>%
  select(산업,주사업_산업분류부호_대분류코드, 권역, 입지계수)

# wide format: 산업을 행, 권역을 열
lq_wide <- lq_table %>%
  pivot_wider(names_from = 권역, values_from = 입지계수) %>%
  arrange(주사업_산업분류부호_대분류코드)

# 결과 출력
print(lq_wide)

# 엑셀 파일 저장 (파일명은 원하는 대로 변경 가능)
write_xlsx(lq_wide, path = "권역별사업체집계정보_입지계수.xlsx")

# 교재 139 페이지
##########################################
# 4. 계층적 군집 분석
##########################################

# 4-1. 사업체수, 종사자수 군집분석
# 필요한 패키지 로드
library(dplyr)
library(cluster)
library(factoextra)

# 자치구별 주요 변수 정리
clust_data <- Business_Survey %>%
  group_by(구) %>%
  summarise(
    사업체수 = n(),
    종사자수 = sum(종사자수_계_합계, na.rm = TRUE)
  ) %>%
  ungroup()  # 그룹 해제(안전하게 사용)

# 결과 확인
print(clust_data)


# tibble → data.frame 변환 및 행이름 지정
clust_data <- as.data.frame(clust_data)
rownames(clust_data) <- clust_data$구
clust_data$구 <- NULL  # 분석에서 제외

# 정규화
clust_data_scaled <- scale(clust_data)

# 거리 행렬 생성
dist_matrix <- dist(clust_data_scaled, method = "euclidean")

# 계층적 군집분석
hc <- hclust(dist_matrix, method = "ward.D2")

windows(width = 10, height = 10)
# 덴드로그램 시각화
fviz_dend(hc, 
          k = 4, 
          rect = TRUE, 
          rect_fill = TRUE,
          main = "서울시 자치구 계층적 군집분석") +
  theme(
    text = element_text(family = "SeoulNamsan"),
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5)
  )


# 교재 140 페이지
# 4-2 산점도


# 필요한 패키지 로드
library(ggplot2)
library(scales)  # 숫자 콤마 처리를 위한 패키지

# 패키지 설치 (처음 한 번만)
# install.packages("ggrepel")

# 패키지 로드
library(ggrepel)

str(clust_data)


# 자치구별 주요 변수 정리
clust_data <- Business_Survey %>%
  group_by(구) %>%
  summarise(
    사업체수 = n(),
    종사자수 = sum(종사자수_계_합계, na.rm = TRUE)
  ) %>%
  ungroup()  # 그룹 해제(안전하게 사용)

# 결과 확인
print(clust_data)

# 산점도 with 구 레이블 (겹치지 않게)
windows(width = 10, height = 10)
ggplot(clust_data, aes(x = 사업체수, y = 종사자수, label = 구)) +
  geom_point(size = 4, color = "blue") +
  geom_text_repel(size = 5, family = "SeoulNamsan") +  # ggrepel 사용
  labs(
    title = "자치구별 사업체수 vs 종사자수 산점도",
    x = "사업체수",
    y = "종사자수"
  ) +
  scale_x_continuous(labels = comma) +
  scale_y_continuous(labels = comma) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5),
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 12)
  )


# 교재 142 페이지
# 4-3. 사업체수, 종사자 유형별 수 군집분석(1)

library(dplyr)

# 구별 사업체수 + 자영업자 종사자수 집계
clust_data_ja <- Business_Survey %>%
  group_by(구) %>%
  summarise(
    사업체수 = n(),
    종사자수_계_자영업자 = sum(종사자수_계_자영업자, na.rm = TRUE)
  ) %>%
  ungroup()

# 확인
print(clust_data_ja)

library(ggplot2)
library(scales)


# 산점도 그리기
windows(width = 20, height = 12)
ggplot(clust_data_ja, aes(x = 사업체수, y = 종사자수_계_자영업자, label = 구)) +
  geom_point(size = 4, color = "blue") +
  geom_text(vjust = -1, size = 5, family = "SeoulNamsan") +
  labs(
    title = "구별 사업체수 vs 자영업자 종사자수",
    x = "사업체수",
    y = "자영업자 종사자수"
  ) +
  scale_x_continuous(labels = comma) +
  scale_y_continuous(labels = comma) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5)
  )


library(dplyr)

# 구별 사업체수 + 상용근로자 종사자수 집계
clust_data_sang <- Business_Survey %>%
  group_by(구) %>%
  summarise(
    사업체수 = n(),
    종사자수_계_상용근로자 = sum(종사자수_계_상용근로자, na.rm = TRUE)
  ) %>%
  ungroup()

# 확인
print(clust_data_sang)

library(ggplot2)
library(scales)

# 산점도 그리기
windows(width = 20, height = 12)
ggplot(clust_data_sang, aes(x = 사업체수, y = 종사자수_계_상용근로자, label = 구)) +
  geom_point(size = 4, color = "blue") +
  geom_text(vjust = -1, size = 5, family = "SeoulNamsan") +
  labs(
    title = "구별 사업체수 vs 상용근로자 종사자수",
    x = "사업체수",
    y = "상용근로자 종사자수"
  ) +
  scale_x_continuous(labels = comma) +
  scale_y_continuous(labels = comma) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5)
  )


# 구별 사업체수 + 상용근로자 종사자수 집계
clust_data_mugub <- Business_Survey %>%
  group_by(구) %>%
  summarise(
    사업체수 = n(),
    종사자수_계_무급가족종사자 = sum(종사자수_계_무급가족종사자, na.rm = TRUE)
  ) %>%
  ungroup()

# 확인
print(clust_data_mugub)

library(ggplot2)
library(scales)

# 산점도 그리기
windows(width = 20, height = 12)
ggplot(clust_data_mugub, aes(x = 사업체수, y = 종사자수_계_무급가족종사자, label = 구)) +
  geom_point(size = 4, color = "blue") +
  geom_text(vjust = -1, size = 5, family = "SeoulNamsan") +
  labs(
    title = "구별 사업체수 vs 무급가족종사자 종사자수",
    x = "사업체수",
    y = "무급가족종사자 종사자수"
  ) +
  scale_x_continuous(labels = comma) +
  scale_y_continuous(labels = comma) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5)
  )

library(dplyr)

# 구별 사업체수 + 임시및일용근로자 종사자수 집계
clust_data_imsi <- Business_Survey %>%
  group_by(구) %>%
  summarise(
    사업체수 = n(),
    종사자수_계_임시및일용근로자 = sum(종사자수_계_임시및일용근로자, na.rm = TRUE)
  ) %>%
  ungroup()

# 확인
print(clust_data_imsi)

library(ggplot2)
library(scales)

# 산점도 그리기
windows(width = 20, height = 12)
ggplot(clust_data_imsi, aes(x = 사업체수, y = 종사자수_계_임시및일용근로자, label = 구)) +
  geom_point(size = 4, color = "blue") +
  geom_text(vjust = -1, size = 5, family = "SeoulNamsan") +
  labs(
    title = "구별 사업체수 vs 임시및일용근로자 종사자수",
    x = "사업체수",
    y = "임시및일용근로자 종사자수"
  ) +
  scale_x_continuous(labels = comma) +
  scale_y_continuous(labels = comma) +
  theme_minimal(base_family = "SeoulNamsan") +
  theme(
    plot.title = element_text(size = 18, face = "bold", hjust = 0.5)
  )


# 교재 143 페이지
# 4-4. 사업체수, 종사자 유형별 수 군집분석(2)

library(dplyr)
library(tidyverse)

# 군집분석용 데이터 준비
clust_data <- Business_Survey %>%
  group_by(구) %>%
  summarise(
    사업체수 = n(),
    종사자수_계_자영업자 = sum(종사자수_계_자영업자, na.rm = TRUE),
    종사자수_계_무급가족종사자 = sum(종사자수_계_무급가족종사자, na.rm = TRUE),
    종사자수_계_상용근로자 = sum(종사자수_계_상용근로자, na.rm = TRUE),
    종사자수_계_임시및일용근로자 = sum(종사자수_계_임시및일용근로자, na.rm = TRUE),
    종사자수_계_기타종사자 = sum(종사자수_계_기타종사자, na.rm = TRUE),
    종사자수_계_합계 = sum(종사자수_계_합계, na.rm = TRUE)
  ) %>%
  ungroup()

# 결과 확인
print(clust_data)

# 숫자변수만 추출해서 scale() → rownames를 "구"로 설정
clust_scaled <- clust_data %>%
  column_to_rownames("구") %>%  # rownames로 "구" 지정
  scale()

# 계층적 군집분석
library(cluster)
library(factoextra)


# 계층적 군집분석
hc <- hclust(dist(clust_scaled), method = "ward.D2")


# 덴드로그램 시각화 (라벨=구)
windows(width = 10, height = 10)
fviz_dend(hc, k = 4, rect = TRUE, rect_fill = TRUE,
          main = "서울시 자치구 계층적 군집분석") +
  theme(text = element_text(family = "SeoulNamsan"),
        plot.title = element_text(size = 16, face = "bold", hjust = 0.5))


# 교재 149 페이지
###############################################
# 5. 주성분 분석(Principal Component Analysis)
###############################################

library(dplyr)

# 구별 주요 변수 집계
clust_data_pca <- Business_Survey %>%
  group_by(구) %>%
  summarise(
    사업체수 = n(),
    종사자수_계_자영업자 = sum(종사자수_계_자영업자, na.rm = TRUE),
    종사자수_계_무급가족종사자 = sum(종사자수_계_무급가족종사자, na.rm = TRUE),
    종사자수_계_상용근로자 = sum(종사자수_계_상용근로자, na.rm = TRUE),
    종사자수_계_임시및일용근로자 = sum(종사자수_계_임시및일용근로자, na.rm = TRUE),
    종사자수_계_기타종사자 = sum(종사자수_계_기타종사자, na.rm = TRUE),
    종사자수_계_합계 = sum(종사자수_계_합계, na.rm = TRUE)
  ) %>%
  ungroup()

# 확인
print(clust_data_pca)


# 5-1 PCA (주성분 분석) + 2차원 구성
library(tibble)
library(ggplot2)
library(factoextra)

# 스케일링 + rownames = "구"
clust_scaled_pca <- clust_data_pca %>%
  column_to_rownames("구") %>%
  scale()

# PCA 수행
pca_result <- prcomp(clust_scaled_pca, center = TRUE, scale. = TRUE)


# PCA 결과 2차원 시각화
windows(width = 15, height = 10)

fviz_pca_ind(pca_result,
             geom.ind = c("point", "text"),  # 점 + 텍스트 동시에
             col.ind = "black",
             repel = TRUE,
             label = "all",                  # 라벨 활성화
             title = "서울시 자치구 PCA (2차원)",
             font.family = "SeoulNamsan"     # 라벨 + 제목 + 전체 폰트 적용
) +
  theme(text = element_text(family = "SeoulNamsan"),
        plot.title = element_text(size = 16, face = "bold", hjust = 0.5))

# 5-2 계층적 군집분석 수행
hc_pca <- hclust(dist(clust_scaled_pca), method = "ward.D2")
cluster_assignments <- cutree(hc_pca, k = 4)  # k는 원하는 군집 개수

print(cluster_assignments)

windows(width = 10, height = 10)
fviz_pca_ind(pca_result,
             geom.ind = c("point", "text"),
             col.ind = factor(cluster_assignments),  # 군집 색상 적용
             palette = "jco",                        # 예쁜 색상 팔레트
             addEllipses = TRUE,                     # 군집 타원 추가
             repel = TRUE,
             title = "서울시 자치구 PCA + 군집",
             font.family = "SeoulNamsan"             # 🔥 폰트 적용 (라벨까지 적용)
) +
  theme(text = element_text(family = "SeoulNamsan"),
        plot.title = element_text(size = 16, face = "bold", hjust = 0.5))


