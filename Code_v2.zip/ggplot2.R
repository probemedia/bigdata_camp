rm(list = ls())  # 모든 객체 삭제
gc()  # 메모리 정리

# 1.1 package 설치
# install.packages("tidyverse")
# install.packages("tidymodels")

# 1.2 library 로드
library(tidyverse)
library(tidymodels)

# (Page 41)
# 2.데이터 불러오기
# 자동차관련데이터(내장데이터)
data(mpg)

# 데이터확인하기
glimpse(mpg)
str(mpg)
mpg

# install.packages("ggplot2")
library(ggplot2)

# x 축 displ, y 축 hwy 로 지정해 배경 생성
ggplot(data = mpg, aes(x = displ, y = hwy)) 

# 배경에 산점도 추가
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point() 


# (Page 44)
# x 축 범위 3~6 으로 지정
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point() + 
  xlim(3, 6)

# 축 범위 3~6, y 축 범위 10~30 으로 지정
ggplot(data = mpg, aes(x = displ, y = hwy)) + 
  geom_point() + 
  xlim(3, 6) + 
  ylim(10, 30) 

# (Page 47)
# mpg 데이터의 cty(도시 연비)와 hwy(고속도로 연비) 간에 어떤 관계가 있는지 ?
ggplot(data = mpg, aes(x = cty, y = hwy)) + geom_point() 

# (Page 50)
ggplot(data = midwest, aes(x = poptotal, y = popasian)) + 
  geom_point() + 
  xlim(0, 500000) + 
  ylim(0, 10000) 

# (Page 51)
library(dplyr) 
df_mpg <- mpg %>% 
  group_by(drv) %>% 
  summarise(mean_hwy = mean(hwy)) 

df_mpg 

ggplot(data = df_mpg, aes(x = drv, y = mean_hwy)) + 
  geom_col()

ggplot(data = df_mpg, 
       aes(x = reorder(drv, -mean_hwy), 
           y = mean_hwy)) + geom_col()

# x 축 범주 변수, y 축 빈도 
ggplot(data = mpg, aes(x = drv)) + geom_bar()

# x 축 연속 변수, y 축 빈도
ggplot(data = mpg, aes(x = hwy)) + geom_bar() 


# (Page 55)
# 평균 표 생성
df <- mpg %>%
  filter(class == "suv") %>%
  group_by(manufacturer) %>%
  summarise(mean_cty = mean(cty)) %>%
  arrange(desc(mean_cty)) %>%
  head(5)

# 그래프 생성
ggplot(data = df, 
       aes(x = reorder(manufacturer, -mean_cty),
           y = mean_cty)) + geom_col()

# (Page 56)
ggplot(data = mpg, aes(x = class)) + geom_bar()

# (Page 57)
ggplot(data = economics, aes(x = date, y = unemploy)) + 
  geom_line() 

# (Page 60)
ggplot(data = economics, aes(x = date, y = psavert)) + geom_line() 

# (Page 61)
ggplot(data = mpg, aes(x = drv, y = hwy)) + geom_boxplot() 

# (Page 64)
class_mpg <- mpg %>% filter(class %in% c("compact", "subcompact", "suv")) 
ggplot(data = class_mpg, aes(x = class, y = cty)) + geom_boxplot() 


