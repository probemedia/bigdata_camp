# ==========================================================
# Business_Survey_Full_Template.R
# (서울시 사업체조사 통합 처리 스크립트 - 전체 구조화/리팩토링)
# ==========================================================
rm(list = ls())
gc()  # 메모리 정리

# ==========================================================
# 01. 패키지 로드 및 경로 설정
# ==========================================================
# install.packages("readxl")
# install.packages("writexl")
# install.packages("dplyr")
# install.packages("stringr")
# install.packages("purrr")
# install.packages("tidyr")
# install.packages("data.table")

library(readxl)
library(writexl)
library(dplyr)
library(stringr)
library(purrr)
library(glue)
library(tidyr)
library(data.table)

# 저장 경로
save_path <- "C:/Project/Data/"

# ==========================================================
# 02. 원본 파일 목록 및 메타정보 정의
# ==========================================================
file_list <- c(
  "C:/Project/Data/서울시 사업체조사결과 정보 (2019년)/2019년 서울시 사업체조사결과파일 필드명.xlsx",
  "C:/Project/Data/서울시 사업체조사결과 정보 (2020년)/2020 사업체조사 결과 필드설명.xlsx",
  "C:/Project/Data/서울시 사업체조사결과 정보(2021년)/2021 사업체조사 결과 필드설명.xlsx",
  "C:/Project/Data/서울시사업체조사결과정보(2022년)/2022 발간용 파일 필드설명.xlsx",
  "C:/Project/Data/서울시사업체조사결과정보(2023년 기준)/2023년 기준 전국사업체조사 잠정 레이아웃(공통).xlsx"
)

sheet_list <- c(
  "행정구역(2019.12.31.)",
  "(참고)행정구역분류",
  "(참고)행정구역분류",
  "(참고)행정구역분류",
  "행정구역 분류"
)

skip_list <- c(0, 2, 2, 4, 2)
year_list <- c("2019", "2020", "2021", "2022", "2023")

# ==========================================================
# 03. 행정구역 데이터 처리 함수 정의
# ==========================================================
source_admin_region <- function(file, sheet, year, skip_n) {
  message(glue("Reading admin region → {year}: {sheet} (skip {skip_n})"))
  df <- read_excel(file, sheet = sheet, skip = skip_n)
  
  # 컬럼명 유무 확인 후 선택적 매핑
  col_대분류 <- ifelse("대분류" %in% colnames(df), "대분류", NA)
  col_시도 <- ifelse("시도" %in% colnames(df), "시도", NA)
  col_중분류 <- ifelse("중분류" %in% colnames(df), "중분류", NA)
  col_시군구 <- ifelse("시군구" %in% colnames(df), "시군구", NA)
  col_영문표기 <- ifelse("영문 표기" %in% colnames(df), "영문 표기", NA)
  col_한자표기 <- ifelse("한자 표기" %in% colnames(df), "한자 표기", NA)
  
  # 2022년 특수 처리
  if (year == "2022") {
    df_selected <- df %>%
      transmute(
        대분류 = 시도코드,
        시도 = 시도명,
        중분류 = 시군구코드,
        시군구 = 시군구명,
        소분류 = as.character(행정구역코드),
        읍면동 = 읍면동명,
        영문표기 = 영문읍면동명,
        한자표기 = NA,
        출처연도 = year
      )
  } else {
    col_소분류 <- ifelse("소분류" %in% colnames(df), "소분류", NA)
    col_읍면동코드 <- ifelse("읍면동코드" %in% colnames(df), "읍면동코드",
                        ifelse("읍면동" %in% colnames(df), "읍면동", NA))
    
    if (is.na(col_소분류) | is.na(col_읍면동코드)) {
      warning(glue("⚠️ {year} → 소분류/읍면동코드 컬럼 누락"))
    }
    
    df_selected <- df %>%
      transmute(
        대분류 = if (!is.na(col_대분류)) as.character(.data[[col_대분류]]) else NA,
        시도 = if (!is.na(col_시도)) as.character(.data[[col_시도]]) else NA,
        중분류 = if (!is.na(col_중분류)) as.character(.data[[col_중분류]]) else NA,
        시군구 = if (!is.na(col_시군구)) as.character(.data[[col_시군구]]) else NA,
        소분류 = if (!is.na(col_소분류)) as.character(.data[[col_소분류]]) else NA,
        읍면동 = if (!is.na(col_읍면동코드)) as.character(.data[[col_읍면동코드]]) else NA,
        영문표기 = if (!is.na(col_영문표기)) as.character(.data[[col_영문표기]]) else NA,
        한자표기 = if (!is.na(col_한자표기)) as.character(.data[[col_한자표기]]) else NA,
        출처연도 = year
      )
  }
  
  return(df_selected)
}

# ==========================================================
# 04. 행정구역 데이터 전체 병합 및 저장
# ==========================================================
admin_region_list <- pmap(
  list(file_list, sheet_list, year_list, skip_list),
  source_admin_region
)

admin_region_all <- bind_rows(admin_region_list)

write.csv(admin_region_all, paste0(save_path, "통합_행정구역분류_Key_통합.csv"), row.names = FALSE)
message("✅ admin_region_all 저장 완료")

# ==========================================================
# 05. 산업분류 데이터 처리 (별도 모듈 추천)
# ==========================================================
# 연도 목록
year_list <- 2019:2023

# -----------------------------------
# 05-1 함수 정의
# -----------------------------------

# (1) 2019년용 함수
read_industry_classification_2019 <- function(file_path, sheet_name) {
  
  df <- read_excel(file_path, sheet = sheet_name)
  
  df <- df %>% select(코드 = 1, 산업분류명 = 2)
  
  df <- df %>%
    mutate(
      코드 = str_trim(as.character(코드)),
      nchar = str_length(코드),
      대분류_코드 = if_else(nchar == 1, 코드, NA_character_),
      대분류_항목명 = if_else(nchar == 1, 산업분류명, NA_character_),
      중분류_코드 = if_else(nchar == 2, 코드, NA_character_),
      중분류_항목명 = if_else(nchar == 2, 산업분류명, NA_character_),
      소분류_코드 = if_else(nchar == 3, 코드, NA_character_),
      소분류_항목명 = if_else(nchar == 3, 산업분류명, NA_character_),
      세분류_코드 = if_else(nchar == 4, 코드, NA_character_),
      세분류_항목명 = if_else(nchar == 4, 산업분류명, NA_character_),
      세세분류_코드 = if_else(nchar == 5, 코드, NA_character_),
      세세분류_항목명 = if_else(nchar == 5, 산업분류명, NA_character_)
    ) %>%
    fill(everything(), .direction = "down") %>%
    select(
      대분류_코드, 대분류_항목명,
      중분류_코드, 중분류_항목명,
      소분류_코드, 소분류_항목명,
      세분류_코드, 세분류_항목명,
      세세분류_코드, 세세분류_항목명
    )
  
  return(df)
}

# (2) 2020~2023년용 함수
read_industry_classification <- function(file_path, sheet_name, start_row) {
  
  df <- read_excel(file_path, sheet = sheet_name, skip = start_row - 1)
  
  names(df)[1:10] <- c(
    "대분류_코드", "대분류_항목명", 
    "중분류_코드", "중분류_항목명", 
    "소분류_코드", "소분류_항목명", 
    "세분류_코드", "세분류_항목명", 
    "세세분류_코드", "세세분류_항목명"
  )
  
  df <- df %>% fill(everything(), .direction = "down")
  
  return(df)
}

# -----------------------------------
# 05-2 연도별 산업분류 데이터 만들기
# -----------------------------------
# (1) 결과 담을 리스트

industry_list <- list()

# 루프 시작
for (i in seq_along(year_list)) {
  
  year <- year_list[i]
  file_path <- file_list[i]
  
  message(paste0("====== [", year, "] 처리 시작 ======"))
  
  # 시트명 체크용 (디버그)
  sheets <- excel_sheets(file_path)
  print(sheets)
  
  # 분기 처리
  if (year == 2019) {
    # 2019년
    df_year <- read_industry_classification_2019(
      file_path = file_path,
      sheet_name = "산업분류"
    )
    
  } else {
    # 2020~2023년
    sheet_name <- ifelse(year == 2023, "표준산업분류(10차)", "(참고)산업분류")
    
    if (!(sheet_name %in% sheets)) {
      stop(paste0("⚠️ [", year, "] 시트명 [", sheet_name, "] 없음!"))
    }
    
    df_year <- read_industry_classification(
      file_path = file_path,
      sheet_name = sheet_name,
      start_row = 3
    )
  }
  
  # 결과 확인
  message(paste0("✅ [", year, "] 읽은 데이터 rows: ", nrow(df_year)))
  
  # 연도 추가
  df_year <- df_year %>% mutate(연도 = year)
  
  # 리스트 저장
  industry_list[[as.character(year)]] <- df_year
}

# 루프 끝난 후 확인
length(industry_list)

# (2) 최종 통합

industry_total <- bind_rows(industry_list)

# industry_total 내부에서 연도 형식 변환 적용
industry_total <- industry_total %>%
  mutate(연도 = as.character(연도))


# (3) 결과 확인
glimpse(industry_total)

# (4) 저장
save(industry_total, file = paste0(save_path, "industry_total_5Years.RData"))
# write.xlsx(industry_total, file = paste0(save_path, "industry_total_5Years.xlsx"))

# Business_Survey List 초기화
Business_Survey_List <- list()

# ==========================================================
# 06. Business_Survey 연도별 처리 루프
# ==========================================================
# 연도 리스트
year_list <- c(2019, 2020, 2021, 2022, 2023)

# 파일 타입 맵
file_type_map <- c(
  "2019" = "excel",
  "2020" = "csv",
  "2021" = "csv",
  "2022" = "csv",
  "2023" = "csv"
)

# 파일 경로 템플릿
file_path_template <- "C:/Project/Data/{year}_Business_Survey.{ext}"

# Business_Survey List 초기화
Business_Survey_List <- list()


var_order_2020 <- c(
  "SURV_BASE_YEAR",
  "AD_CD",
  "ESTM_RPRS_SD_CD",
  "ESTM_RPRS_GNR_CD",
  "FND_YEAR",
  "FND_MM",
  "ORGFM_DIV_CD",
  "ESTM_DIV_CD",
  "INDST_LCLS_CD",
  "MBZ_INDST_CLS_CD",
  "CE_WOKE_SUBS",
  "CE_MWK_CNT",
  "CE_WWK_CNT",
  "TPDLY_WORK_SUBS",
  "TPDLY_MWK_CNT",
  "TPDLY_WWK_CNT",
  "SLFM_WOKE_SUBS",
  "SLFM_MWK_CNT",
  "SLFM_WWK_CNT",
  "UPF_WOKE_SUBS",
  "UPF_MWK_CNT",
  "UPF_WWK_CNT",
  "OTR_WOKE_SUBS",
  "OTR_MWK_CNT",
  "OTR_WWK_CNT",
  "WOKE_ALL_SUM",
  "MWK_SUM",
  "WWK_SUM"
)

col_mapping_2020 <- c(
  "SURV_BASE_YEAR"      = "SURV_BASE_YEAR",
  "AD_CD"               = "AD_CD",
  "ESTM_RPRS_SD_CD"     = "RPRS_SD_CD",
  "ESTM_RPRS_GNR_CD"    = "RPRS_GNR",
  "FND_YEAR"            = "FND_YEAR",
  "FND_MM"              = "FND_MM",
  "ORGFM_DIV_CD"        = "ORG_FORM_CD",
  "ESTM_DIV_CD"         = "ESTM_DIV_CD",
  "INDST_LCLS_CD"       = "INDST_LCLS_CD",
  "MBZ_INDST_CLS_CD"    = "MBZ_INDST_DIV_CD",
  
  "SLFM_WOKE_SUBS"      = "SURV_PHS_SLFM_SUM",
  "SLFM_MWK_CNT"        = "SURV_PHS_SLFM_MAN_CNT",
  "SLFM_WWK_CNT"        = "SURV_PHS_SLFM_WMAN_CNT",
  
  "UPF_WOKE_SUBS"       = "SURV_PHS_UPF_SUM",
  "UPF_MWK_CNT"         = "SURV_PHS_UPF_MAN_CNT",
  "UPF_WWK_CNT"         = "SURV_PHS_UPF_WMAN_CNT",
  
  "CE_WOKE_SUBS"        = "SURV_PHS_CE_SUM",
  "CE_MWK_CNT"          = "SURV_PHS_CE_MAN_CNT",
  "CE_WWK_CNT"          = "SURV_PHS_CE_WMAN_CNT",
  
  "TPDLY_WORK_SUBS"     = "SURV_PHS_TMPR_DALY_SUM",
  "TPDLY_MWK_CNT"       = "SURV_PHS_TMPR_DALY_MAN_CNT",
  "TPDLY_WWK_CNT"       = "SURV_PHS_TMPR_DALY_WMAN_CNT",
  
  "OTR_WOKE_SUBS"       = "SURV_PHS_OTR_SUM",
  "OTR_MWK_CNT"         = "SURV_PHS_OTR_MAN_CNT",
  "OTR_WWK_CNT"         = "SURV_PHS_OTR_WMAN_CNT",
  
  "WOKE_ALL_SUM"        = "SURV_PHS_WOKE_SUM",
  "MWK_SUM"             = "SURV_PHS_MAN_SUM",
  "WWK_SUM"             = "SURV_PHS_WMAN_SUM"
)

col_mapping_2021 <- c(
  "SURV_BASE_YEAR"      = "SURV_BASE_YEAR",
  "AD_CD"               = "AD_CD",
  "RPRS_SD_CD"          = "RPRS_SD_CD",
  "RPRS_GNR"            = "RPRS_GNR",
  "FND_YEAR"            = "FND_YEAR",
  "FND_MM"              = "FND_MM",
  "ORG_FORM_CD"         = "ORG_FORM_CD",
  "ESTM_DIV_CD"         = "ESTM_DIV_CD",
  "INDST_LCLS_CD"       = "INDST_LCLS_CD",
  "MBZ_INDST_DIV_CD"    = "MBZ_INDST_DIV_CD",
  
  "SLFM_SUM"            = "SURV_PHS_SLFM_SUM",
  "SLFM_MAN_CNT"        = "SURV_PHS_SLFM_MAN_CNT",
  "SLFM_WMAN_CNT"       = "SURV_PHS_SLFM_WMAN_CNT",
  
  "UPF_SUM"             = "SURV_PHS_UPF_SUM",
  "UPF_MAN_CNT"         = "SURV_PHS_UPF_MAN_CNT",
  "UPF_WMAN_CNT"        = "SURV_PHS_UPF_WMAN_CNT",
  
  "CE_SUM"              = "SURV_PHS_CE_SUM",
  "CE_MAN_CNT"          = "SURV_PHS_CE_MAN_CNT",
  "CE_WMAN_CNT"         = "SURV_PHS_CE_WMAN_CNT",
  
  "TMPR_DALY_SUM"       = "SURV_PHS_TMPR_DALY_SUM",
  "TMPR_DALY_MAN_CNT"   = "SURV_PHS_TMPR_DALY_MAN_CNT",
  "TMPR_DALY_WMAN_CNT"  = "SURV_PHS_TMPR_DALY_WMAN_CNT",
  
  "OTR_SUM"             = "SURV_PHS_OTR_SUM",
  "OTR_MAN_CNT"         = "SURV_PHS_OTR_MAN_CNT",
  "OTR_WMAN_CNT"        = "SURV_PHS_OTR_WMAN_CNT",
  
  "WOKE_SUM"            = "SURV_PHS_WOKE_SUM",
  "MAN_SUM"             = "SURV_PHS_MAN_SUM",
  "WMAN_SUM"            = "SURV_PHS_WMAN_SUM"
)


common_col_names <- c(
  "SURV_BASE_YEAR","AD_CD","RPRS_SD_CD","RPRS_GNR","FND_YEAR","FND_MM",
  "ORG_FORM_CD","ESTM_DIV_CD",
  "INDST_LCLS_CD",
  "MBZ_INDST_DIV_CD",
  "SURV_PHS_SLFM_SUM","SURV_PHS_SLFM_MAN_CNT","SURV_PHS_SLFM_WMAN_CNT",
  "SURV_PHS_UPF_SUM","SURV_PHS_UPF_MAN_CNT","SURV_PHS_UPF_WMAN_CNT",
  "SURV_PHS_CE_SUM","SURV_PHS_CE_MAN_CNT","SURV_PHS_CE_WMAN_CNT",
  "SURV_PHS_TMPR_DALY_SUM","SURV_PHS_TMPR_DALY_MAN_CNT","SURV_PHS_TMPR_DALY_WMAN_CNT",
  "SURV_PHS_OTR_SUM","SURV_PHS_OTR_MAN_CNT","SURV_PHS_OTR_WMAN_CNT",
  "SURV_PHS_WOKE_SUM","SURV_PHS_MAN_SUM","SURV_PHS_WMAN_SUM"
)


check_column_match <- function(df, common_col_names, year_str) {
  
  actual_col_names <- names(df)
  
  # 누락된 컬럼 (common_col_names 기준으로 없으면 누락)
  missing_cols <- setdiff(common_col_names, actual_col_names)
  
  # 추가된 컬럼 (df 안에는 있는데 common_col_names에 없으면 추가)
  extra_cols <- setdiff(actual_col_names, common_col_names)
  
  # 순서 확인 (optional)
  is_order_correct <- identical(actual_col_names, common_col_names)
  
  # 결과 출력
  cat(glue("\n[{year_str}] 컬럼 점검 결과"))
  cat("\n---------------------------------------\n")
  
  if (length(missing_cols) == 0) {
    cat("✅ 누락된 컬럼 없음\n")
  } else {
    cat("❌ 누락된 컬럼:", paste(missing_cols, collapse = ", "), "\n")
  }
  
  if (length(extra_cols) == 0) {
    cat("✅ 추가된 컬럼 없음\n")
  } else {
    cat("❌ 추가된 컬럼:", paste(extra_cols, collapse = ", "), "\n")
  }
  
  if (is_order_correct) {
    cat("✅ 컬럼 순서 일치\n")
  } else {
    cat("⚠️ 컬럼 순서 불일치\n")
  }
  
  cat("---------------------------------------\n\n")
  
  # return list (원하면 후속 처리용)
  return(list(
    missing_cols = missing_cols,
    extra_cols = extra_cols,
    is_order_correct = is_order_correct
  ))
}

add_industry_hierarchy <- function(df, industry_total) {
  
  df <- df %>%
    mutate(연도 = as.character(SURV_BASE_YEAR),  # 연도 형식 맞추기 (industry_total은 chr)
           INDST_LCLS_CD_chr = as.character(INDST_LCLS_CD),  # 기존 코드 형식
           MBZ_INDST_DIV_CD_chr = as.character(MBZ_INDST_DIV_CD))  # 기존 코드 형식
  # INDST_LCLS_CD 산업대분류
  
  # 대분류명 추가
  df <- df %>%
    left_join(industry_total %>%
                select(대분류_코드, 대분류_항목명, 연도) %>% distinct(),
              by = c("INDST_LCLS_CD_chr" = "대분류_코드", "연도")) %>%
    rename(MBZ_INDST_DIV_NAME = 대분류_항목명)
  
  # 중분류명 추가
  df <- df %>%
    mutate(MBZ_INDST_MID_CD = str_sub(MBZ_INDST_DIV_CD_chr, 1, 2)) %>%
    left_join(industry_total %>%
                select(중분류_코드, 중분류_항목명, 연도) %>% distinct(),
              by = c("MBZ_INDST_MID_CD" = "중분류_코드", "연도")) %>%
    rename(MBZ_INDST_MID_NAME = 중분류_항목명)
  
  # 소분류명 추가
  df <- df %>%
    mutate(MBZ_INDST_SML_CD = str_sub(MBZ_INDST_DIV_CD_chr, 1, 3)) %>%
    left_join(industry_total %>%
                select(소분류_코드, 소분류_항목명, 연도) %>% distinct(),
              by = c("MBZ_INDST_SML_CD" = "소분류_코드", "연도")) %>%
    rename(MBZ_INDST_SML_NAME = 소분류_항목명)
  
  # 세분류명 추가
  df <- df %>%
    mutate(MBZ_INDST_CLS_CD = str_sub(MBZ_INDST_DIV_CD_chr, 1, 4)) %>%
    left_join(industry_total %>%
                select(세분류_코드, 세분류_항목명, 연도) %>% distinct(),
              by = c("MBZ_INDST_CLS_CD" = "세분류_코드", "연도")) %>%
    rename(MBZ_INDST_CLS_NAME = 세분류_항목명)
  
  # 세세분류명 추가
  df <- df %>%
    mutate(MBZ_INDST_DTL_CD = str_sub(MBZ_INDST_DIV_CD_chr, 1, 5)) %>%
    left_join(industry_total %>%
                select(세세분류_코드, 세세분류_항목명, 연도) %>% distinct(),
              by = c("MBZ_INDST_DTL_CD" = "세세분류_코드", "연도")) %>%
    rename(MBZ_INDST_DTL_NAME = 세세분류_항목명)
  
  # 정리
  df <- df %>%
    select(-MBZ_INDST_MID_CD, -MBZ_INDST_SML_CD, -MBZ_INDST_CLS_CD, -MBZ_INDST_DIV_CD_chr, -MBZ_INDST_DTL_CD, -연도)
  
  return(df)
}


check_gender_sum <- function(df, year_str, save_path) {
  
  # 각 오류 레코드 추출
  df_error <- df %>%
    mutate(
      check_slfm = SURV_PHS_SLFM_SUM != (SURV_PHS_SLFM_MAN_CNT + SURV_PHS_SLFM_WMAN_CNT),
      check_upf = SURV_PHS_UPF_SUM != (SURV_PHS_UPF_MAN_CNT + SURV_PHS_UPF_WMAN_CNT),
      check_ce = SURV_PHS_CE_SUM != (SURV_PHS_CE_MAN_CNT + SURV_PHS_CE_WMAN_CNT),
      check_tmpr_daly = SURV_PHS_TMPR_DALY_SUM != (SURV_PHS_TMPR_DALY_MAN_CNT + SURV_PHS_TMPR_DALY_WMAN_CNT),
      check_otr = SURV_PHS_OTR_SUM != (SURV_PHS_OTR_MAN_CNT + SURV_PHS_OTR_WMAN_CNT),
      check_total = SURV_PHS_WOKE_SUM != (SURV_PHS_MAN_SUM + SURV_PHS_WMAN_SUM)
    ) %>%
    filter(
      check_slfm | check_upf | check_ce | check_tmpr_daly | check_otr | check_total
    )
  
  # 오류 건수 요약
  cat(glue("\n[{year_str}] 남+여 합계 오류 레코드 수: {nrow(df_error)} 건\n"))
  
  # 엑셀로 저장 (파일명: Business_Survey_Error_{year}.xlsx)
  if (nrow(df_error) > 0) {
    error_file_path <- paste0(save_path, "Business_Survey_Error_", year_str, ".xlsx")
    writexl::write_xlsx(df_error, path = error_file_path)
    cat(glue("❗ 오류 레코드 엑셀 저장 완료 → {error_file_path}\n"))
  } else {
    cat("\n✅ 오류 없음 → 엑셀 저장 생략\n")
  }
}

# 파일 복사 스크립트

# 복사 함수
copy_file <- function(from, to) {
  if (file.exists(from)) {
    success <- file.copy(from, to, overwrite = TRUE)
    if (success) {
      message(paste("복사 완료:", to))
    } else {
      warning(paste("복사 실패:", from))
    }
  } else {
    warning(paste("원본 파일 없음:", from))
  }
}

# 파일 경로 정의 및 복사 실행
copy_file("C:/Project/Data/서울시 사업체조사결과 정보 (2019년)/2019년 기준 서울시 사업체조사결과.xlsx",
          "C:/Project/Data/2019_Business_Survey.xlsx")

copy_file("C:/Project/Data/서울시 사업체조사결과 정보 (2020년)/2020년 사업체조사.csv",
          "C:/Project/Data/2020_Business_Survey.csv")

copy_file("C:/Project/Data/서울시 사업체조사결과 정보(2021년)/2021사업체조사결과.csv",
          "C:/Project/Data/2021_Business_Survey.csv")

copy_file("C:/Project/Data/서울시사업체조사결과정보(2022년)/2022년 기준 사업체조사.csv",
          "C:/Project/Data/2022_Business_Survey.csv")

copy_file("C:/Project/Data/서울시사업체조사결과정보(2023년 기준)/2023년 기준 사업체조사.csv",
          "C:/Project/Data/2023_Business_Survey.csv")


# ---- 루프 시작 ----
for (year in year_list) {
  
  year_str <- as.character(year)
  message(paste0("========== [", year, "] Business_Survey 처리 시작 =========="))
  
  ext <- ifelse(file_type_map[year_str] == "csv", "csv", "xlsx")
  
  file_path <- gsub("\\{year\\}", year, file_path_template)
  file_path <- gsub("\\{ext\\}", ext, file_path)
  
  # --- 1️⃣ 파일 읽기 ---
  if (ext == "csv") {
    df_temp <- read.csv(file_path, encoding = "utf-8")
  } else {
    df_temp <- read_excel(file_path)
  }
  
  # --- 2️⃣ 변수명 매핑 처리 (연도별) ---
  # 기존 col_mapping_2020, col_mapping_2021, common_col_names 유지
  # 함수화 가능: map_column_names(year_str, df_temp)
  
  if (year_str == "2020") {
    
    # 재배열 적용
    df_temp <- df_temp %>% select(all_of(var_order_2020))
    
    
    names(df_temp) <- ifelse(names(df_temp) %in% names(col_mapping_2020),
                             col_mapping_2020[names(df_temp)],
                             names(df_temp))  # 매핑 없는 경우 그대로 유지
    # 컬럼 점검
    check_column_match(df_temp, common_col_names, year_str)
    
    # 컬럼명 강제 정렬
    names(df_temp) <- common_col_names
    cat("✅ 컬럼 순서 일치\n")
    
    
  } else if (year_str == "2021") {
    
    # 2021년용 매핑 적용
    names(df_temp) <- ifelse(names(df_temp) %in% names(col_mapping_2021),
                             col_mapping_2021[names(df_temp)],
                             names(df_temp))
    
    # 컬럼 점검
    check_column_match(df_temp, common_col_names, year_str)
    
    # 컬럼명 강제 정렬
    names(df_temp) <- common_col_names
    cat("✅ 컬럼 순서 일치\n")
    
    
  } else {
    # --- 3️⃣ 컬럼 점검 ---
    # check_column_match(df_temp, common_col_names, year_str)
    # 2019, 2022, 2023 → 기존 common_col_names 적용
    check_column_match(df_temp, common_col_names, year_str)
    names(df_temp) <- common_col_names
  }
  
  
  # --- 4️⃣ char_vars 변환 ---
  char_vars <- c(
    "SURV_BASE_YEAR", "AD_CD", "RPRS_SD_CD", "RPRS_GNR", "FND_YEAR", "FND_MM",
    "ORG_FORM_CD", "ESTM_DIV_CD", "INDST_LCLS_CD", "MBZ_INDST_DIV_CD"
  )
  
  df_temp[char_vars] <- lapply(df_temp[char_vars], as.character)
  
  # --- 5️⃣ admin_region_all 조인 ---
  admin_region_year <- admin_region_all %>%
    filter(출처연도 == year_str) %>%
    mutate(Gu_Code = substr(소분류, 1, 5)) %>%
    select(소분류, 시군구, 읍면동, Gu_Code, Gu_Name = 시군구, Dong_Name = 읍면동)
  
  df_temp <- df_temp %>%
    left_join(admin_region_year, by = c("AD_CD" = "소분류"))
  
  # --- 5-1️⃣ MBZ_INDST_DIV_CD 자리수 보정 ---
  df_temp <- df_temp %>%
    mutate(MBZ_INDST_DIV_CD = as.character(MBZ_INDST_DIV_CD)) %>%
    mutate(MBZ_INDST_DIV_CD = if_else(nchar(MBZ_INDST_DIV_CD) == 4,
                                      paste0("0", MBZ_INDST_DIV_CD),
                                      MBZ_INDST_DIV_CD))
  
  # --- 6️⃣ 산업분류 계층 조인 ---
  df_temp <- add_industry_hierarchy(df_temp, industry_total)
  
  # 점검 대상 변수 (✅ 컬럼명만 넣기)
  check_vars <- c("MBZ_INDST_DIV_NAME", "MBZ_INDST_MID_NAME", "MBZ_INDST_SML_NAME", "MBZ_INDST_CLS_NAME")
  
  # NA 건수 확인
  for (var in check_vars) {
    na_count <- sum(is.na(df_temp[[var]]))
    na_percent <- round(na_count / nrow(df_temp) * 100, 2)
    
    cat(sprintf("🔍 %s: NA %d건 (%.2f%%)\n", var, na_count, na_percent))
  }
  
  # --- 7️⃣ 리스트 저장 & CSV 저장 ---
  Business_Survey_List[[year_str]] <- df_temp
  
  write.csv(df_temp, paste0(save_path, "Business_Survey_", year_str, ".csv"), row.names = FALSE)
  message(paste0("✅ [", year, "] Business_Survey 처리 완료 (", nrow(df_temp), " rows)"))
  
  # --- 8️⃣ 남+여 합계 검증 ---
  check_gender_sum(df_temp, year_str, save_path)
}

# MBZ_INDST_DIV_NAME 이 NA 인 경우만 필터링해서 별도 데이터프레임 저장
df_na_div_name <- df_temp %>%
  filter(is.na(MBZ_INDST_DIV_NAME))

# 확인 (예: 상위 10건)
head(df_na_div_name, 10)

# 필요시 CSV로 저장
# write.csv(df_na_div_name, paste0(save_path, "NA_MBZ_INDST_DIV_NAME_", year_str, ".csv"), row.names = FALSE)

cat(sprintf("✅ [연도 %s] MBZ_INDST_DIV_NAME NA %d건 별도 파일로 저장 완료\n", 
            year_str, nrow(df_na_div_name)))

# ==========================================================
# 07. Business_Survey 전체 통합 및 저장
# ==========================================================
# 파일 경로 리스트 만들기
file_paths <- paste0(save_path, "Business_Survey_", year_list, ".csv")

# fread + rbindlist로 빠르게 통합
Business_Survey_List <- lapply(file_paths, fread)
Business_Survey <- rbindlist(Business_Survey_List, fill = TRUE)

# --- 최종 컬럼 순서 정리 ---

final_col_order <- c(
  "SURV_BASE_YEAR", "Gu_Code", "Gu_Name", "AD_CD", "Dong_Name",
  "MBZ_INDST_DIV_CD", "MBZ_INDST_DIV_NAME", "MBZ_INDST_MID_NAME", "MBZ_INDST_SML_NAME", "MBZ_INDST_CLS_NAME","MBZ_INDST_DTL_NAME",
  "RPRS_SD_CD", "RPRS_GNR", "FND_YEAR", "FND_MM", "ORG_FORM_CD", "ESTM_DIV_CD",
  "SURV_PHS_SLFM_SUM", "SURV_PHS_SLFM_MAN_CNT", "SURV_PHS_SLFM_WMAN_CNT",
  "SURV_PHS_UPF_SUM", "SURV_PHS_UPF_MAN_CNT", "SURV_PHS_UPF_WMAN_CNT",
  "SURV_PHS_CE_SUM", "SURV_PHS_CE_MAN_CNT", "SURV_PHS_CE_WMAN_CNT",
  "SURV_PHS_TMPR_DALY_SUM", "SURV_PHS_TMPR_DALY_MAN_CNT", "SURV_PHS_TMPR_DALY_WMAN_CNT",
  "SURV_PHS_OTR_SUM", "SURV_PHS_OTR_MAN_CNT", "SURV_PHS_OTR_WMAN_CNT",
  "SURV_PHS_WOKE_SUM", "SURV_PHS_MAN_SUM", "SURV_PHS_WMAN_SUM"
)

Business_Survey <- Business_Survey %>% select(all_of(final_col_order))

# --- NA → 0 처리 (숫자형 컬럼 대상) ---
num_vars <- Business_Survey %>%
  select(where(is.numeric)) %>%
  colnames()

for (col in num_vars) {
  Business_Survey[is.na(get(col)), (col) := 0]
}

# --- 최종 검증 출력 ---
# 기존 check_slfm, check_upf ... check_total 출력 유지

str(Business_Survey)
# TEMP
# ==========================================================
# 남+여 합계 검증
# ==========================================================

# 자영업자
check_slfm <- sum(Business_Survey$SURV_PHS_SLFM_SUM != 
                    Business_Survey$SURV_PHS_SLFM_MAN_CNT + Business_Survey$SURV_PHS_SLFM_WMAN_CNT, na.rm = TRUE)

# 무급가족종사자
check_upf <- sum(Business_Survey$SURV_PHS_UPF_SUM != 
                   Business_Survey$SURV_PHS_UPF_MAN_CNT + Business_Survey$SURV_PHS_UPF_WMAN_CNT, na.rm = TRUE)

# 상용근로자
check_ce <- sum(Business_Survey$SURV_PHS_CE_SUM != 
                  Business_Survey$SURV_PHS_CE_MAN_CNT + Business_Survey$SURV_PHS_CE_WMAN_CNT, na.rm = TRUE)

# 임시 및 일용근로자
check_tmpr_daly <- sum(Business_Survey$SURV_PHS_TMPR_DALY_SUM != 
                         Business_Survey$SURV_PHS_TMPR_DALY_MAN_CNT + Business_Survey$SURV_PHS_TMPR_DALY_WMAN_CNT, na.rm = TRUE)

# 기타종사자
check_otr <- sum(Business_Survey$SURV_PHS_OTR_SUM != 
                   Business_Survey$SURV_PHS_OTR_MAN_CNT + Business_Survey$SURV_PHS_OTR_WMAN_CNT, na.rm = TRUE)

# 전체 종사자 합계
check_total <- sum(Business_Survey$SURV_PHS_WOKE_SUM != 
                     Business_Survey$SURV_PHS_MAN_SUM + Business_Survey$SURV_PHS_WMAN_SUM, na.rm = TRUE)

# 결과 출력
cat("자영업자 남+여 ≠ 합계 오류건수:", check_slfm, "\n")
cat("무급가족종사자 남+여 ≠ 합계 오류건수:", check_upf, "\n")
cat("상용근로자 남+여 ≠ 합계 오류건수:", check_ce, "\n")
cat("임시 및 일용근로자 남+여 ≠ 합계 오류건수:", check_tmpr_daly, "\n")
cat("기타종사자 남+여 ≠ 합계 오류건수:", check_otr, "\n")
cat("전체 종사자 남+여 ≠ 전체합계 오류건수:", check_total, "\n")

# 최종 판정
if (check_slfm == 0 & check_upf == 0 & check_ce == 0 & 
    check_tmpr_daly == 0 & check_otr == 0 & check_total == 0) {
  cat("\n✅ 모든 남+여 합계 검증 통과!!\n")
} else {
  cat("\n❌ 일부 합계 오류 발견됨. 확인 필요.\n")
}

# TEMP


# --- 최종 저장 ---
save(Business_Survey, file = paste0(save_path, "Business_Survey_5Years.RData"))

message("========== ✅ Business_Survey 전체 통합 및 저장 완료 ✅ ==========")


