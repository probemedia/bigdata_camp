# https://rstudio.github.io/leaflet/
# 공간데이터 표현
install.packages("leaflet")
library(leaflet)

m = leaflet() %>% addTiles()
m

# 서울시청을 중심으로 표현
m = m %>% setView(126.9783785, 37.5666612, zoom=17)
m

label_name = "서울시청"
# 팝업표시
m %>% addPopups(126.9783785, 37.5666612, label_name)

# 마커표시
m %>%
  addMarkers(lng=126.978378, lat=37.5666612, label=label_name, popup=label_name)

# 사용자정의 마커
# https://www.jla-data.net/eng/leaflet-markers-in-r/

m %>%
  addMarkers(lng=126.978378, lat=37.5666612, label=label_name, popup=label_name,
             icon = makeIcon(iconUrl = "img/s.png", iconWidth=25, iconHeight=25))

# 사용자정의 마커, 지도 종류 변경
# https://rstudio.github.io/leaflet/articles/basemaps.html
m %>%
  addMarkers(lng=126.978378, lat=37.5666612, label=label_name, popup=label_name,
             icon = makeIcon(iconUrl = "img/s.png", iconWidth=25, iconHeight=25)) %>% 
  addProviderTiles("CartoDB.Positron")
