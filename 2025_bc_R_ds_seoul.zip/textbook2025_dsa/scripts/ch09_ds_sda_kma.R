# 주요 패키지 로드
library(readxl)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(gridExtra)
library(corrplot)
library(forecast)

# 서울과 철원의 폭염지속일수 차이 비교
df_ht <- read.csv("data/2012-2021_ht.csv")

# 지점이 서울과 철원 데이터
df_ht2 <- df_ht %>%
  filter(지점 %in% c("서울","철원")) %>%
  select(지점, 지속일수)

df_ht2

# 지점이 서울과 철원 데이터수 파악
table(df_ht2$지점)

# 지점이 서울인 지속일수 요약통계량
df_ht2 %>% filter(지점=='서울') %>% select(지속일수) %>% summary()

# 지점 철원인 지속일수 요약통계량
df_ht2 %>% filter(지점=='철원') %>% select(지속일수) %>% summary()

# 지점별 지속일수비교 병렬상자그림
df_ht2 %>% ggplot(aes(지점, 지속일수)) + geom_boxplot()

# 가설검정
t.test(data=df_ht2, 지속일수 ~ 지점, var.equal=T)


#---
# 서울시 평균온도 회귀분석
df_ta <- read.csv("data/2012-2021_seoul_an_ta.csv")

# 데이터 파악
head(df_ta)
tail(df_ta)
dim(df_ta)
str(df_ta)

# 2) 요약통계량, 결측치 확인
# df_ta데이터프레임의 수량형 변수 요약통계량 확인
summary(df_ta)

# 3) 데이터 형태파악을 위한 시각화
# 산점도 행렬
pairs(df_ta[, 2:11])

# 상관행렬
df_ta_cor <- cor(df_ta[, 2:11])
df_ta_cor

# 상관행렬 히트맵
corrplot(df_ta_cor, method="number")

# 평균기온, 한파일수 변수 산점도
df_ta %>% ggplot(aes(평균기온, 한파일수)) + geom_point()

# 평균기온, 한파일수 변수 산점도: 단순 회귀 - 비선형 모형
df_ta %>% ggplot(aes(평균기온, 한파일수)) + geom_point() + geom_smooth()

# 평균기온, 한파일수 변수 산점도도: 단순 선형 모형
df_ta %>% ggplot(aes(평균기온, 한파일수)) + geom_point() + 
  geom_smooth(method='lm', formula=y~x)

# 4) 상관계수
# 평균기온, 한파일수 변수의 상관계수: 피어슨 방식
cor(df_ta$평균기온, df_ta$한파일수, use="complete.obs")

# 평균기온, 한파일수 변수의 상관계수: 스피어만 방식
cor(df_ta$평균기온, df_ta$한파일수, method="spearman", 
    use="complete.obs")

# 평균기온, 한파일수 변수의 상관계수: 캔달 방식
cor(df_ta$평균기온, df_ta$한파일수, method="kendall", 
    use="complete.obs")

# 5) 단순 회귀분석 - lm()
# 선형모형을 최소제곱법으로 추정
ta_lm <- lm(평균기온 ~ 한파일수, data=df_ta)
ta_lm

# 추정치와 각 모수값이 0인지 가설검정
summary(ta_lm)

# 7) 선형회귀 모형 예측
# 반응변수CH4_ppm의 예측값
predict(ta_lm)

# 잔차계산
resid(ta_lm)

# 새로운 데이터 한파일수=c(12, 13, 14)에 따른 평균기온 예측값 
predict(ta_lm, newdata=data.frame(한파일수=c(12, 13, 14)))

# 새로운 데이터 한파일수=c(12, 13, 14)에 따른 평균기온 예측값 및 예측오차
predict(ta_lm, newdata=data.frame(한파일수=c(12, 13, 14)), se.fit=TRUE)

# 8) 선형회귀 모형의 가정 진단
# 선형회귀 모형 진단 플롯
par(mfrow=c(2, 2))
plot(ta_lm, las=1) # las=1, 축레벨이 축과 평행
dev.off() # 2x2형태의 시각화 해제

# 그래프 파일로 저장
png("plots/ta_lrd_plot.png", 5.5, 4, units="in", 
    pointsize=9, res=600)
par(mfrow=c(2, 2))
plot(ta_lm, las=1)
dev.off()

# 9) 로버스트 선형회귀분석 - lqs()
# 이산화탄소 배출량(CO2값)에 가장 큰 영향을 변수 확인
library(MASS)  # lqs() 제공

# 난수시드 고정
set.seed(2110)
# 로버스트 선형회귀분석
#lqs(평균기온 ~ ., data=df_ta[, 2:11])

# 최소제곱법 선형회귀분석
lm(평균기온 ~ ., data=df_ta[, 2:11])  

# 10) 비선형(비모수적) 방법- 평활법: LOESS
# 산점도로 CO2_ppm와 CH4_ppm의 관계및 분포확인
df_ta %>% ggplot(aes(평균기온, 한파일수)) + geom_point()

# LOESS를 사용한 비선형 회귀분석
ghgs_lo <- loess(한파일수 ~ 평균기온, data=df_ta)
ghgs_lo

# 비선형 회귀분석의 예측선 시각화: 산점도에 geom_smooth() 추가
df_ta %>% ggplot(aes(평균기온, 한파일수)) + geom_point() + geom_smooth()


#---
# 오존데이터, 온실가스데이터 결측치/이상치 처리 및 
# STL분해를 사용한 주기성 시계열 데이터 분해

# 오존데이터
df_ozone <- read.csv("data/ozone_data.csv")
df_ozone2 <- df_ozone
# 데이터 파악
names(df_ozone2)
head(df_ozone2)
tail(df_ozone2)
str(df_ozone2)
summary(df_ozone2)

df_ozone2$평균오존전량.DU. <- df_ozone2$평균오존전량.DU. %>% tsclean()
class(df_ozone2$평균오존전량.DU.)

# 이상치 보정데이터 파일로 저장
df_ozone2$평균오존전량.DU. <- round(trunc(df_ozone2$평균오존전량.DU. * 100) / 100, 1)
write.csv(df_ozone2, "data/ozone_data2.csv")

# 오존데이터의 STL분해
stl(ts(df_ozone2$평균오존전량.DU., start=2013, frequency=12), 
    s.window="periodic") %>% autoplot()

# 온실가스 데이터
df_ghgs <- read.csv("data/1999-2020_ghgs.csv")
df_ghgs2 <- df_ghgs[, 2:9]
# 데이터 파악
names(df_ghgs2)
head(df_ghgs2)
tail(df_ghgs2)
str(df_ghgs2)
summary(df_ghgs2)

# 반복문으로 여러개의 결측 변수 처리 
i <- 2
for(x in df_ghgs2[, 2:8]){
  df_ghgs2[i] <- round(trunc(na.interp(x) * 100) / 100, 1)
  i = i + 1
}

# 결측치 보정데이터 파일로 저장
write.csv(df_ghgs2, "data/1999-2020_ghgs2.csv")

stl(ts(df_ghgs2$CO2_ppm, start=1999, frequency=12), s.window="periodic") %>% autoplot()
stl(ts(df_ghgs2$CH4_ppm, start=1999, frequency=12), s.window="periodic") %>% autoplot()
stl(ts(df_ghgs2$N2O_ppm, start=1999, frequency=12), s.window="periodic") %>% autoplot()

#
for(x in df_ghgs2[, 2:8]){
  stl(ts(unlist(x), start=1999, frequency=12), 
      s.window="periodic") %>% autoplot()
}

