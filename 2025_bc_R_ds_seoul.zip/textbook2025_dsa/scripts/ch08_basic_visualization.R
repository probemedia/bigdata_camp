# 8. 시각화

#-----
# 8-001. 필요패키지 설치 및 로드
# tidyverse, gridExtra 패키지 설치
install.packages("tidyverse")
install.packages("gridExtra")

# 주요 패키지 로드
library(readxl)
library(dplyr)
library(ggplot2)
library(tidyverse)
library(gridExtra)


#-----
# 8-002. 산점도 행렬
library(gapminder)
df_gap <- gapminder

target <- c("lifeExp", "pop", "gdpPercap")
pairs(df_gap[,target])  


#-----
# 8-003. 산점도 행렬 파일로 저장
# 방법1: png()함수 사용
png("plots/gap_pairs.png", 5.5, 4, units="in", pointsize=9, res=600)
target <- c("lifeExp", "pop", "gdpPercap")
pairs(df_gap[,target])
dev.off()

# 방법2: ggsave()함수 사용
library(gridExtra)
g1 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point()
g2 <- df_gap %>% ggplot(aes(x=gdpPercap, y=pop)) + geom_point()
g <- arrangeGrob(g1, g2, ncol=2)
ggsave("plots/gap_pairs2.png", plot=g, width=6, height=4, units="in", dpi=600)


#-----
# 8-004. 상관계수
# df_gap의 1인당 gdp와 기대수명의 피어슨 방식 상관계수 
cor(df_gap$gdpPercap, df_gap$lifeExp)

# df_gap의 1인당 gdp와 기대수명의 스피어만 방식 상관계수 
cor(df_gap$gdpPercap, df_gap$lifeExp, method="spearman")

# df_gap의 1인당 gdp와 기대수명의 캔달 방식 상관계수 
cor(df_gap$gdpPercap, df_gap$lifeExp, method="kendall")


#-----
# 8-005. 관측치에 NA값이 있는 경우 상관계수
df_ghgs <- read.csv("data/1999-2023_ghgs.csv", fileEncoding="cp949")

# CO2_ppm와 CH4_ppm에 NA값 확인
summary(df_ghgs[, 3:4])

# CO2_ppm와 CH4_ppm의 상관 계수 구함
cor(df_ghgs$CO2_ppm, df_ghgs$CH4_ppm, use="complete.obs")


#-----
# 8-006. ggplot()함수를 사용한 그래프 작성 방법
library(dplyr)
library(ggplot2)

# df_mpg데이터프레임 생성
df_mpg <- mpg

# 방법1: 데이터프레임을 ggplot()함수 안에 넣어서 작성
ggplot(data=df_mpg, aes(x=displ, y=hwy)) + geom_point()

# 방법2: 데이터프레임 %>% ggplot()함수 사용
df_mpg %>% ggplot(aes(x=displ, y=hwy)) + geom_point()


#-----
# 8-007.그래프 종류별 작도 - 산점도
# geom_point()함수를 사용 배기량과 고속도로 연비 산점도
df_mpg %>% ggplot(aes(x=displ, y=hwy)) + geom_point()

# geom_jitter()함수를 사용한 배기량과 고속도로 연비 산점도
set.seed(2110)
df_mpg %>% ggplot(aes(x=displ, y=hwy)) + geom_jitter()

# 산점도에 회귀선 추가
df_mpg %>% ggplot(aes(x=displ, y=hwy)) + geom_point() + geom_smooth()

# 산점도에 선형 회귀선 추가
df_mpg %>% ggplot(aes(x=displ, y=hwy)) + geom_point() + 
  geom_smooth(method='lm', formula=y~x)

# 1인당 gdp와 기대수명의 관계를 표현한 산점도
df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point()

# 1인당 gdp와 기대수명의 관계를 표현한 산점도에 로그추가
df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() + 
  scale_x_log10()

# 1인당 gdp와 기대수명의 관계를 표현한 산점도에 로그추가, 선형 회귀선 추가
df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() +
  scale_x_log10() + geom_smooth(method='lm', formula=y~x)

# 1인당 gdp와 기대수명의 관계 서브플롯 파일로 저장
g1 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point()
g2 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() + scale_x_log10()
g3 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_point() +
  scale_x_log10() + geom_smooth(method='lm', formula=y~x)
g <- arrangeGrob(g1, g2, g3, ncol=3)
ggsave("plots/gdpPercap_lifeExp.png", g, width=8, height=4, 
       units="in", dpi=600)


#-----
# 8-008.그래프 종류별 작도 - 막대그래프
# geom_bar()함수를 사용한 빈도 막대 그래프
df_mpg %>% ggplot(aes(x=class)) + geom_bar()

# geom_col()함수를 사용한 x(범주)에 해당하는 y(값) 막대 그래프
# 차종별 도시연비 평균값을 가진 df1 생성
df1 <- df_mpg %>%
  group_by(class) %>%
  summarise(mean_cty=mean(cty))
df1

# 차종별 도시연비 평균 막대그래프
df1 %>% ggplot(aes(x=class, y=mean_cty)) + geom_col()


#-----
# 8-009.그래프 종류별 작도 - 선그래프
# 1999년~2022년까지 우리나라의 온실가스 측정 데이터 로드
df_ghgs <- read.csv("data/1999-2023_ghgs.csv", fileEncoding="cp949")

# df_ghgs의 복제본 df_ghgs1 생성후 변수 속성파악
df_ghgs1 <- df_ghgs
str(df_ghgs1)

# 문자열로 로드된 시간변수를 날짜타입으로 변환
df_ghgs1$시간 <- as.Date(df_ghgs1$시간)
str(df_ghgs1)

# 1999~2022까지 CO2배출량의 변화추이: 시계열 그래프 작성
df_ghgs1 %>% ggplot(aes(x=시간, y=CO2_ppm)) + geom_line()

# 1999~2022까지 CO2배출량의 변화추이: 시계열 그래프에 선형회귀선 추가
df_ghgs1 %>% ggplot(aes(x=시간, y=CO2_ppm)) + geom_line() + 
  geom_smooth(method='lm', formula=y~x)

# 1999~2022까지 CO2배출량의 변화추이 서브플롯 작성 후 파일로 저장
g1 <- df_ghgs1 %>% ggplot(aes(x=시간, y=CO2_ppm)) + geom_line()
g2 <- df_ghgs1 %>% ggplot(aes(x=시간, y=CO2_ppm)) + geom_line() + 
  geom_smooth(method='lm', formula=y~x)
g <- arrangeGrob(g1, g2, ncol=2)
ggsave("plots/1999-2023_CO2.png", g, width=6, height=4, 
       units="in", dpi=600)


#-----
# 8-010.그래프 종류별 작도 - 선그래프(선형보간법)
# 1999~2022까지 CH4배출량 추이: 시계열 그래프 작성
df_ghgs1 %>% ggplot(aes(x=시간, y=CH4_ppm)) + geom_line()

# 1999~2022까지 CH4배출량의 결측치 처리후 시계열 그래프 작성
library(forecast)

df_p2 <- df_ghgs1[, 2:4]
df_p2$CO2_ppm <- na.interp(df_p2$CO2_ppm)
df_p2$CH4_ppm <- na.interp(df_p2$CH4_ppm)
df_p2 %>% ggplot(aes(x=시간, y=CH4_ppm)) + geom_line()

# 결측보간 후 시계열그래프 
df_co2 <- df_ghgs1 %>% select(시간, CO2_ppm)
str(df_co2)

df_co2$시간 <- as.Date(df_co2$시간)
df_co2$CO2_ppm <- na.interp(df_co2$CO2_ppm)
df_co2$CO2_ppm <- as.numeric(df_co2$CO2_ppm)

str(df_co2)
df_co2 %>% ggplot(aes(x=시간, y=CO2_ppm)) + geom_line() + geom_smooth(method='lm', formula=y~x)

# 결측보간 후 STL분해 사용
df_co2 <- df_ghgs1 %>% select(시간, CO2_ppm)
str(df_co2)
df_co2$CO2_ppm <- na.interp(df_co2$CO2_ppm)
stl(ts(df_co2$CO2_ppm, start=1999, frequency=12), s.window="periodic") %>% autoplot()

#-----
# 8-011.그래프 종류별 작도 - 선그래프 여러개 플롯
# 1999~2023까지 CO2배출량추이와 CH4배출량 추이
df2
# CO2배출량 추이 그래프 저장, 그래프색 파랑
g_mul <- df_ghgs1 %>% ggplot(aes(x=시간, y=CO2_ppm)) + geom_line(color="blue")

# 4.3.2~4.4.1에서 한글 타이틀, 레이블 표시안됨
# CO2배출량 추이 그래프 저장된 변수에 CH4배출량 추이 중첩
g_mul + geom_line(aes(x=시간, y=CH4_ppm), color="red") + ylab("온실가스배경농도")

df_ghgs1 %>% ggplot(aes(x=시간, y=CO2_ppm)) + geom_line(color="blue") + 
  geom_line(aes(x=시간, y=CH4_ppm), color="red") + 
  theme(plot.title = element_text(hjust = 0.5)) + 
  labs(title="Greenhouse Gas", y ="ppm", x="time") 

# 1999~2022까지 CO2배출량추이와 CH4배출량 추이에서 y축레이블 회전
df_ghgs1 %>% ggplot(aes(x=시간, y=CO2_ppm)) + geom_line(color="blue") + 
  geom_line(aes(x=시간, y=CH4_ppm), color="red") + 
  labs(title="온실가스 배경농도 추이", y ="ppm", x="관측일") +
  theme(axis.title.y=element_text(angle=0)) 


#-----
# 8-012.그래프 종류별 작도 - 히스토그램
# gapminder: 1952~2007년까지 5년마다 관측한 국가별 기대수명, 1인당 gdp, 인구수의 추이
library(gapminder)
df_gap <- gapminder

# 데이터 탐색
head(df_gap)
tail(df_gap)
str(df_gap)
summary(df_gap)

# df_gap의 gdpPercap변수에 대한 도수 히스토그램 작성
df_gap %>% ggplot(aes(x=gdpPercap)) + geom_histogram()

# df_gap의 gdpPercap변수에 대한 도수 히스토그램 작성 - bins조절
df_gap %>% ggplot(aes(x=gdpPercap)) + geom_histogram(bins=50)

# df_gap의 gdpPercap변수에 대한 도수 히스토그램 작성 - 로그추가
df_gap %>% ggplot(aes(x=gdpPercap)) + geom_histogram() + scale_x_log10()

# df_gap의 gdpPercap변수에 대한 도수 폴리곤 작성 - 로그추가
df_gap %>% ggplot(aes(x=gdpPercap)) + geom_freqpoly() + scale_x_log10()

# df_gap의 gdpPercap변수에 대한 커널밀도추정(확률밀도함수) 작성 - 로그추가
df_gap %>% ggplot(aes(x=gdpPercap)) + geom_density() + scale_x_log10()

# 1952~2007까지 5년마다 관측한 1인당gdp의 히스토그램 서브플롯 작성 후 저장
g1 <- df_gap %>% ggplot(aes(x=gdpPercap)) + geom_histogram(bins=50)
g2 <- df_gap %>% ggplot(aes(x=gdpPercap)) + geom_histogram(bins=50) +
  scale_x_log10()
g3 <- df_gap %>% ggplot(aes(x=gdpPercap)) + geom_freqpoly(bins=50) +
  scale_x_log10()
g4 <- df_gap %>% ggplot(aes(x=gdpPercap)) + geom_density() +  scale_x_log10()
g <- arrangeGrob(g1, g2, g3, g4, ncol=2)
ggsave("plots/1952-2007_gdpPercap_hist.png", g, width=6, height=6, 
       units="in", dpi=600)


#-----
# 8-013.그래프 종류별 작도 - 병렬 상자그림
# mpg: 1999~2008년 미국출시 자동차 연비 데이터
library(ggplot2)
df_mpg <- mpg

head(df_mpg)
tail(df_mpg)
str(df_mpg)

# 자동차 구동방식별 도시주행 연비 비교
df_mpg %>% ggplot(aes(x=drv, y=cty)) + geom_boxplot()

# 자동차종별 도시주행 연비 비교
df_mpg %>% ggplot(aes(x=class, y=cty)) + geom_boxplot()

# 자동차종별 도시주행 연비 비교: 산점도+병렬 상자그림
set.seed(2110)
df_mpg %>% ggplot(aes(x=class, y=cty)) + geom_jitter() + 
  geom_boxplot(alpha=.5)

# 1999~2008년 미국출시 자동차 도시주행 연비 비교 서브플롯 작성 후 저장
g1 <- df_mpg %>% ggplot(aes(x=drv, y=cty)) + geom_boxplot()
g2 <- df_mpg %>% ggplot(aes(x=class, y=cty)) + geom_boxplot()
set.seed(2110)
g3 <- df_mpg %>% ggplot(aes(x=class, y=cty)) + geom_jitter() + 
  geom_boxplot(alpha=.5)
g <- arrangeGrob(g1, g2, g3, ncol=3)
ggsave("plots/1999~2008_class_cty_boxplot.png", g, width=8, height=3, 
       units="in", dpi=600)


#-----
# 8-014.그래프 종류별 작도 - 히트맵
# hexbin패키지 설치 및 로드
install.packages("hexbin")
library(hexbin)

# 1인당 gdp와 기대수명의 관계 히트맵
df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_hex() +
  scale_fill_gradient(name = "count", trans = "log")

df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_hex(bins=50) +
  scale_fill_gradient(name = "count", trans = "log")

# 1인당 gdp와 기대수명의 관계 히트맵, 로그추가
df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_hex() + scale_x_log10() +
  scale_fill_gradient(name = "count", trans = "log", low="red", high="yellow")

# 1인당 gdp와 기대수명의 관계 히트맵, 로그추가, 선형회귀선 추가
df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_hex() + scale_x_log10() +
  scale_fill_gradient(name = "count", trans = "log", low="red", high="yellow") +
  geom_smooth(method='lm', formula=y~x)

# gapminder데이터를 사용한 1인당gdp와 기대수명의 관계 히트맵 서브플롯 작성후 저장
g1 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_hex() +
  scale_fill_gradient(name = "count", trans = "log")
g2 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_hex() +
  scale_x_log10() + 
  scale_fill_gradient(name = "count", trans = "log", low="red", high="yellow")
g3 <- df_gap %>% ggplot(aes(x=gdpPercap, y=lifeExp)) + geom_hex() +
  scale_x_log10() +
  scale_fill_gradient(name = "count", trans = "log", low="red", high="yellow") +
  geom_smooth(method='lm', formula=y~x)
g <- arrangeGrob(g1, g2, g3, ncol=3)
ggsave("plots/1952-2007_gdpPercap_lifeExp_hexbin.png", g, width=12, height=4, 
       units="in", dpi=600)


#-----
# 8-015.그래프 종류별 작도 - 상관행렬 히트맵
# corrplot패키지 설치 및 로드
install.packages("corrplot")
library(corrplot)

# 1999-2023까지 월별 온실가스 배출량
df_ghgs <- read.csv("data/1999-2023_ghgs.csv", fileEncoding="cp949")

# df_ghgs데이터탐색
head(df_ghgs)
tail(df_ghgs)
str(df_ghgs)

# df_ghgs데이터에서 수량형 변수만 추출해서 df_ghgs2에 저장
df_ghgs2 <- df_ghgs[, 3:length(df_ghgs)]

# df_ghgs2데이터프레임의 상관행렬을 구함
cor(df_ghgs2, use="complete.obs")

# df_ghgs2의 상관행렬을 df_df_ghgs2_cor에 저장 후 소수점이하 둘째자리까지 구함
df_ghgs2_cor <- cor(df_ghgs2, use="complete.obs")
round(df_ghgs2_cor, 2)

# df_ghgs2_cor에 저장된 상관행렬을 히트맵으로 구함: 관계의 크기를 점의 크기로 표현
corrplot(df_ghgs2_cor)

# df_ghgs2_cor에 저장된 상관행렬을 히트맵으로 구함: 관계의 크기를 숫자로 표현
corrplot(df_ghgs2_cor, method="number")

# 1999-2023까지 월별 온실가스 배출량 상관행렬 히트맵 서브플롯 작성후 저장
png("plots/1999-2023_ghgs_corrplot.png", 6, 4, units="in",
    pointsize=9, res=600)
par(mfrow=c(1, 2))
corrplot(df_ghgs2_cor)
corrplot(df_ghgs2_cor, method="number")
dev.off()

# 1999-2023까지 월별 온실가스 배출량 산점도 행렬 작성후 저장
png("plots/1999-2023_ghgs_pairs.png", 8, 6, units="in", 
    pointsize=9, res=600)
pairs(df_ghgs2)
dev.off()

# 산점도와 상관계수행렬 같이 시각화: pairs.panels()
install.packages("psysh")
library(psysh)
pairs.panels(df_ghgs2)

# 산점도와 상관계수행렬 같이 시각화: ggpairs()
install.packages("GGally")
library(GGally)
ggpairs(df_ghgs2)

# 그래프 저장
g <- ggpairs(df_ghgs2)
ggsave("plots/1999-2023_ghgs_pairs_corrplot.png", g, width=8, height=8, 
       units="in", dpi=600)

# Error in dev.off(): cannot shut down device~ 에러발생시 실행
while (!is.null(dev.list()))  dev.off()


#-------
# 8장 추가실습
--
# 실습1 : 2020년 광역시도별 교통사고 사망자수 비교 막대그래프 작성
# 데이터로드 및 데이터 탐색
library(readxl)
df_td <- read_excel("data/2020_sido_ta.xlsx")
head(df_td)
tail(df_td)
str(df_td)

# df_td에서 사고_발생지역, 사망자수 변수만 선택후 사고_발생지역별 사망자수 합 계산결과 df_td_g에 저장
df_td_g <- df_td %>%
  select(사고_발생지역, 사망자수) %>%
  group_by(사고_발생지역) %>%
  summarise(sum_사망자수=sum(사망자수))
df_td_g

# 광역시도별 교통사고 사망자수 비교 막대그래프
df_td_g %>% ggplot(aes(x=사고_발생지역, y=sum_사망자수)) + geom_col() +
  theme(axis.text.x = element_text(angle=30, hjust=1))


--
# 실습2 : 아산화질소(N2O) 결측치 수정 후 시계열그래프 및 선형회귀추가
# forecast 사용 
# 패키지 및 데이터로드
library(forecast)
df_ghgs <- read.csv("data/1999-2023_ghgs.csv", fileEncoding="cp949")

# df_ghgs의 복제본 df_ghgs1 생성
df_ghgs1 <- df_ghgs

# 문자열로 로드된 시간변수를 날짜타입으로 변환
df_ghgs1$시간 <- as.Date(df_ghgs1$시간)
df_ghgs1

df_p2 <- df_ghgs1[, 2:5]
df_p2$CO2_ppm <- na.interp(df_p2$CO2_ppm)
df_p2$N2O_ppm <- na.interp(df_p2$N2O_ppm)
df_p2 %>% ggplot(aes(x=시간, y=N2O_ppm)) + geom_line()

--
# 실습3 : gapminder데이터에서 2007년 자료만 갖고 히스토그램 작성
# 데이터 생성
library(gapminder)
df_gap <- gapminder

# 2007년 데이터만 추출
df_2007 <- df_gap %>% filter(year==2007)

# 히스토그램, 도수폴리곤, 확률밀도함수 작성
df_2007 %>% ggplot(aes(x=gdpPercap)) + geom_histogram()
df_2007 %>% ggplot(aes(x=gdpPercap)) + geom_histogram() + scale_x_log10()
df_2007 %>% ggplot(aes(x=gdpPercap)) + geom_freqpoly() + scale_x_log10()
df_2007 %>% ggplot(aes(x=gdpPercap)) + geom_density() + scale_x_log10()

--
# 실습4 : 2020년 2월 서울시 지하철 노선별 하차승객 비교: 병렬상자그림
# 데이터로드 및 df_sub데이터프레임생성
df_sub <- read.csv("data/202002_seoul_subway.csv")

# 데이터탐색
head(df_sub)
tail(df_sub)
str(df_sub)

# 지하철 노선별 하차승객 비교: 병렬상자그림
df_sub %>% ggplot(aes(x=노선명, y=하차총승객수)) + geom_boxplot() +
  theme(axis.text.x = element_text(angle=30, hjust=1))


#-------
# 8장 문제 : 서울시 코로나19 확진자현황
# 데이터로드 및 df_c19_now 생성
df_c19_now <- read.csv("data/20211004_seoul_c19.csv")

# 데이터 탐색
head(df_c19_now)
tail(df_c19_now)
str(df_c19_now)

# df_c19_now 데이터프레임의 상태변수의 범주값 확인
table(df_c19_now$상태)

# 상태변수 값 수정
df_c19_now$상태 <- ifelse(df_c19_now$상태=="-", "입원", df_c19_now$상태)
table(df_c19_now$상태)

# 오류값 제거
df_c19_now <- df_c19_now %>% filter(상태!=42)

# 상태변수 빈도막대그래프 작성
df_c19_now %>% ggplot(aes(x = 상태)) + geom_bar()

# 월별 빈도수 구함 : format(as.Date(df_c19_now$확진일), "%Y-%m")
df_c19_now_g <- df_c19_now %>%
  mutate(month = format(as.Date(df_c19_now$확진일), "%Y-%m")) %>%
  count(month)

# 변수명 변경
names(df_c19_now_g) <- c("년_월", "집계수")
df_c19_now_g

# 월별 빈도 막대그래프
df_c19_now_g %>% ggplot(aes(년_월, 집계수)) + geom_col() +
  theme(axis.text.x = element_text(angle=30, hjust=1))

# 년도별 월별 일별 빈도수 : format(as.Date(df_c19_now$확진일), "%Y-%m-%d")
df_c19_now_g2 <- df_c19_now %>%
  mutate(day = format(as.Date(df_c19_now$확진일), "%Y-%m-%d")) %>%
  count(day)

df_c19_now_g2

# 년도별 빈도수: format(as.Date(df_c19_now$확진일), "%Y")
df_c19_now_g3 <- df_c19_now %>%
  mutate(year = format(as.Date(df_c19_now$확진일), "%Y")) %>%
  count(year)

df_c19_now_g3

# 년도별 빈도수 막대그래프
df_c19_now_g3 %>% ggplot(aes(year, n)) + geom_col()

