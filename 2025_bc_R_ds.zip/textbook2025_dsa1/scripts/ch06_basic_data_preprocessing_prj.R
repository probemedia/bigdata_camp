library(readxl)
library(dplyr)

data_files <- list.files(path="data/subway")
data_files

#------
paths <- paste("data/subway/", data_files[1], sep="")
df_subway <- read.csv(paths, fileEncoding="cp949")
df_subway <- df_subway[, 1:5]
#-----
names(df_subway)

#-----

for(dfile in data_files[2:length(data_files)]){
  paths <- paste("data/subway/", dfile, sep="")
  # print(paths)
  df1 <- read.csv(paths, fileEncoding="cp949")
  df1 <- df1[, 1:5]
  df_subway <- bind_rows(df_subway, df1)
}

head(df_subway)
tail(df_subway)
str(df_subway)
names(df_subway)

write.csv(df_subway, "data/2018-2022_seoul_subway.csv", row.names=FALSE)
# write.csv(df_subway, "data/2018-2022_seoul_subway.csv", fileEncoding="cp949")

df_subway <- read.csv("data/2018-2022_seoul_subway.csv")
df_subway

str(df_subway)

class(df_subway$사용일자)
as.character(df_subway$사용일자)
paste(substr(as.character(df_subway$사용일자), 1, 4), 
      substr(as.character(df_subway$사용일자), 5, 6), 
      substr(as.character(df_subway$사용일자), 7, 8), sep="-")

df_subway$사용일자 <- paste(substr(as.character(df_subway$사용일자), 1, 4), 
                        substr(as.character(df_subway$사용일자), 5, 6), 
                        substr(as.character(df_subway$사용일자), 7, 8), sep="-")

str(df_subway)

df_subway$사용일자 <- as.Date(df_subway$사용일자)
str(df_subway)

write.csv(df_subway, "data/2018-2022_seoul_subway.csv", row.names=FALSE)

df_subway <- read.csv("data/2018-2022_seoul_subway.csv")
df_subway

test <- "20180102"
paste(substr(test, 1, 4), substr(test, 5, 6), substr(test, 7, 8), sep="-")

df_subway %>%
  group_by(노선명) %>%  # 노선별
  summarize(n_data=n(),
            tot_승차총승객수=sum(승차총승객수),
            tot_하차총승객수=sum(하차총승객수)) %>%
  arrange(-tot_하차총승객수)
